# specs/DATA_SPEC.md

Schema literal Drizzle e regras de dados. Copiar a estrutura, nao reinterpretar.
Inclui a regra de prazo e timezone, fonte comum de bug silencioso.

---

## 1. Schema Drizzle (drizzle/schema.ts)

Use `pgTable`. Tipos exatos abaixo. Comentarios explicam decisoes que nao podem mudar.

```ts
import { pgTable, uuid, text, integer, boolean, timestamp, primaryKey, unique, index } from 'drizzle-orm/pg-core';

export const users = pgTable('users', {
  id: uuid('id').defaultRandom().primaryKey(),
  email: text('email').notNull().unique(),
  passwordHash: text('password_hash').notNull(),
  nickname: text('nickname').notNull().unique(),
  favoriteTeam: text('favorite_team'),               // codigo do team, null permitido
  role: text('role').notNull().default('user'),      // 'user' | 'admin'
  isPremium: boolean('is_premium').notNull().default(false),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
});

export const teams = pgTable('teams', {
  code: text('code').primaryKey(),     // ex 'BRA'
  name: text('name').notNull(),
  flagCode: text('flag_code').notNull(), // codigo do SVG em /public/flags (ex 'br')
});

export const matches = pgTable('matches', {
  id: text('id').primaryKey(),                         // id do seed, ex 'R16-01'
  phase: text('phase').notNull(),                      // ver Phase em SCORING_SPEC
  grp: text('grp'),                                    // grupo, null no mata-mata
  homeCode: text('home_code').notNull().references(() => teams.code),
  awayCode: text('away_code').notNull().references(() => teams.code),
  stadium: text('stadium').notNull(),
  kickoffAt: timestamp('kickoff_at', { withTimezone: true }).notNull(), // UTC. Prazo.
  homeScore: integer('home_score'),                    // null ate encerrar
  awayScore: integer('away_score'),
  status: text('status').notNull().default('agendada'),// 'agendada'|'ao_vivo'|'encerrada'
}, (t) => ({
  byPhase: index('matches_phase_idx').on(t.phase),
  byKickoff: index('matches_kickoff_idx').on(t.kickoffAt),
}));

export const predictions = pgTable('predictions', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  matchId: text('match_id').notNull().references(() => matches.id),
  homeGuess: integer('home_guess').notNull(),          // 0..20 (validado por Zod)
  awayGuess: integer('away_guess').notNull(),
  points: integer('points').notNull().default(0),      // gravado ao encerrar
  criterion: text('criterion'),                        // gravado ao encerrar (ver RANKING_SPEC 8.4)
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  oneG: unique('predictions_user_match_uq').on(t.userId, t.matchId), // um palpite por partida
  byMatch: index('predictions_match_idx').on(t.matchId),
  byUser: index('predictions_user_idx').on(t.userId),
}));

export const leagues = pgTable('leagues', {
  id: uuid('id').defaultRandom().primaryKey(),
  name: text('name').notNull(),
  ownerId: uuid('owner_id').notNull().references(() => users.id),
  inviteToken: text('invite_token').notNull().unique(), // crypto, nao adivinhavel
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
});

export const leagueMembers = pgTable('league_members', {
  leagueId: uuid('league_id').notNull().references(() => leagues.id, { onDelete: 'cascade' }),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  joinedAt: timestamp('joined_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  pk: primaryKey({ columns: [t.leagueId, t.userId] }),  // membro unico por liga
  byUser: index('league_members_user_idx').on(t.userId),
}));

// Schema agora, UI em V2. Nao implementar fluxo, so existir.
export const specialPredictions = pgTable('special_predictions', {
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  type: text('type').notNull(),     // 'campeao' | 'artilheiro'
  value: text('value').notNull(),   // codigo do team ou nome do jogador
  points: integer('points').notNull().default(0),
}, (t) => ({
  pk: primaryKey({ columns: [t.userId, t.type] }),
}));
```

### 1.1 Decisoes travadas do schema

- `kickoffAt` e `withTimezone: true`, sempre gravado em UTC. Ver secao 3.
- `predictions` tem unique (user_id, match_id). E o que garante um palpite por partida.
  O upsert do palpite usa essa constraint (`onConflictDoUpdate`).
- `criterion` em predictions e gravado junto com points ao encerrar (Opcao A do
  RANKING_SPEC). Permite exact_count sem recomputo.
- `onDelete cascade` em predictions e league_members evita orfaos se um usuario for
  removido.
- Nenhuma coluna guarda total de pontos do usuario. Total e sempre agregado por query.
  Proibido cachear total em coluna no MVP (fonte de inconsistencia).

---

## 2. Validacao de entrada (lib/validations.ts, Zod)

Toda Server Action valida ANTES de tocar o banco. Schemas minimos:

```ts
import { z } from 'zod';

export const scoreSchema = z.object({
  homeGuess: z.number().int().min(0).max(20),
  awayGuess: z.number().int().min(0).max(20),
});

export const signupSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  nickname: z.string().min(3).max(20).regex(/^[A-Za-z0-9_]+$/),
  isAdult: z.literal(true),       // checkbox 16+ obrigatorio
  acceptTerms: z.literal(true),   // aceite obrigatorio
});

export const createLeagueSchema = z.object({
  name: z.string().min(3).max(40),
});

export const adminResultSchema = z.object({
  matchId: z.string(),
  homeScore: z.number().int().min(0).max(30),
  awayScore: z.number().int().min(0).max(30),
});
```

Regra: o range 0..20 do palpite e validado aqui. A funcao de scoring assume entrada
ja valida e nao revalida range.

---

## 3. Prazo, timezone e o bug que precisamos evitar

### 3.1 Regra de prazo

O palpite trava no `kickoffAt` da partida. Apos esse instante, nao cria nem edita.
Validado SEMPRE no servidor, no momento do submit, comparando `new Date()` (UTC) com
`match.kickoffAt` (UTC). Nunca confiar em horario do client.

### 3.2 Tudo em UTC no banco, conversao so na exibicao

- `kickoffAt` gravado em UTC no seed e no banco.
- A comparacao de prazo e UTC vs UTC. Sem conversao, sem ambiguidade.
- A EXIBICAO para o usuario converte para horario de Brasilia (America/Sao_Paulo)
  usando Intl, apenas na renderizacao. Nunca gravar horario local.

```ts
// lib/utils/dates.ts
export function isPredictionOpen(kickoffAt: Date, now: Date = new Date()): boolean {
  return now.getTime() < kickoffAt.getTime();
}

export function formatBrasilia(d: Date): string {
  return new Intl.DateTimeFormat('pt-BR', {
    timeZone: 'America/Sao_Paulo',
    day: '2-digit', month: '2-digit',
    hour: '2-digit', minute: '2-digit',
  }).format(d);
}
```

### 3.3 Edge cases de prazo (enumerados)

| Situacao | Comportamento |
|---|---|
| Submit 1 segundo antes do kickoff | Aceita. now < kickoff. |
| Submit exatamente no kickoff (now === kickoff) | Rejeita. A condicao e estritamente `<`. No instante do apito, fecha. |
| Submit 1 segundo depois | Rejeita com mensagem "Prazo encerrado". |
| Client com relogio adiantado tenta enviar apos prazo | Rejeitado. Validacao e server-side, ignora relogio do client. |
| Partida ja encerrada (status encerrada) | Formulario nem renderiza editavel. Mostra resultado. |
| Edicao de palpite existente antes do prazo | Aceita. Upsert. Vale o ultimo. updatedAt atualiza. |
| Edicao apos prazo | Rejeitada server-side mesmo que a UI tente. |

A condicao canonica de "pode palpitar" e: `status === 'agendada' && isPredictionOpen(kickoffAt)`.
Status `ao_vivo` e `encerrada` nunca permitem palpite.

---

## 4. Token de convite de liga

```ts
// lib/utils/slug.ts
import { randomBytes } from 'crypto';
export function inviteToken(): string {
  // 16 bytes -> 22 chars base64url. Nao adivinhavel, unico na pratica.
  return randomBytes(16).toString('base64url');
}
```

Edge: colisao de token e praticamente impossivel, mas a coluna e unique. Se o insert
falhar por unique violation, gerar outro token e tentar de novo (loop com no maximo
3 tentativas). Documentar no Server Action de criar liga.

---

## 5. Regra de limite de liga (MVP)

- Usuario com `is_premium = false`: pode ser owner OU membro de no maximo 1 liga.
  Antes de criar ou entrar, contar ligas do usuario (owner + member). Se >= 1, bloquear
  com mensagem clara.
- Usuario `is_premium = true`: limite 100 (V2, mas a regra ja le a flag). No MVP,
  como nao ha fluxo de virar premium, todos sao basico e o limite efetivo e 1.

Edge cases de liga:

| Situacao | Comportamento |
|---|---|
| Entrar na mesma liga duas vezes | Bloqueado pela PK (league_id, user_id). Mensagem "voce ja esta nesta liga". |
| Owner tambem conta como membro | Sim. Ao criar, inserir o owner em league_members. Ele ocupa a vaga de 1 liga. |
| Token invalido ou inexistente | Pagina de convite mostra erro "convite invalido". |
| Basico ja em 1 liga tenta criar outra | Bloqueado. "Usuarios basicos podem participar de 1 liga." |
| Liga sem membros alem do owner | Valida. Ranking mostra so o owner. |

---

## 6. Seed (lib/data/copa2026.ts) regras

- Exporta `teams: Team[]` e `matches: SeedMatch[]`.
- `SeedMatch.kickoffAt` e string ISO em UTC (ex '2026-07-04T21:00:00Z') convertida
  para Date no seed script.
- O chaveamento do mata-mata e fixo. No MVP nao ha avanco dinamico: os confrontos sao
  os definidos no seed. Se a Copa real ainda nao definiu adversarios, usar placeholders
  coerentes (ex 'Vencedor Grupo A' vira um team code provisorio) e marcar como dado a
  revisar. Documentar no topo do arquivo quais confrontos sao provisorios.
- Pelo menos um jogo do Brasil deve existir no seed para exercitar o multiplicador x2.
- Cobrir todas as fases do mata-mata para exercitar todos os multiplicadores.

---

## 7. Checklist de verificacao (Task de schema e seed)

- [ ] Schema bate exatamente com este documento, incluindo criterion em predictions.
- [ ] Migracao aplica limpa. Indices criados.
- [ ] unique (user_id, match_id) existe e o upsert usa onConflictDoUpdate.
- [ ] kickoffAt withTimezone, seed em UTC.
- [ ] isPredictionOpen testado para os 3 instantes (antes, igual, depois).
- [ ] Seed popula todas as fases e ao menos um jogo do Brasil.
- [ ] inviteToken gera string unica, coluna unique.
