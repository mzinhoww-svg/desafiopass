# specs/SCORING_SPEC.md

Especificacao normativa da logica de pontuacao. Este documento e a fonte unica da
verdade. Se o codigo divergir daqui, o codigo esta errado. Se este documento estiver
ambiguo, PARE e pergunte. Nunca preencha uma lacuna por conta propria.

Arquivo alvo: `lib/scoring.ts` (funcao pura, sem I/O, sem acesso a banco).
Arquivo de teste: `lib/scoring.test.ts`.

---

## 0. Por que este modulo e isolado e puro

A pontuacao e a regra de negocio mais sensivel do produto. Qualquer divergencia gera
ranking errado, premio errado e perda de confianca. Por isso:

- E funcao pura. Recebe dados, devolve numero. Nao le banco, nao le data do sistema,
  nao tem efeito colateral.
- E testada antes de qualquer UI depender dela (Task 2.1 vem antes da 2.3).
- A regra existe em UM lugar so. Proibido recalcular pontos em Server Action, em
  componente, em SQL ou em qualquer outro arquivo. Todos chamam `finalPoints`.

---

## 1. Tipos (copiar exatamente)

```ts
// Fases do torneio. Strings literais, nunca enum numerico.
export type Phase =
  | 'grupos'
  | '32avos'
  | 'oitavas'
  | 'quartas'
  | 'semi'        // semifinal
  | 'terceiro'    // disputa de 3 e 4 lugar
  | 'final';

// Placar real de uma partida ja encerrada.
export interface MatchResult {
  homeScore: number; // inteiro >= 0
  awayScore: number; // inteiro >= 0
}

// Palpite do usuario para a partida.
export interface Guess {
  homeGuess: number; // inteiro 0..20
  awayGuess: number; // inteiro 0..20
}

// Entrada completa do calculo final.
export interface ScoreInput {
  guess: Guess | null;       // null = usuario nao palpitou no prazo
  result: MatchResult;       // sempre presente (so calcula apos encerrar)
  phase: Phase;
  isBrazilMatch: boolean;    // true se a selecao brasileira joga esta partida
}

// Detalhamento do calculo. Retornado para exibir na UI e para auditar.
export interface ScoreBreakdown {
  base: number;          // pontos-base antes de multiplicador
  criterion: Criterion;  // qual criterio bateu
  brazilMultiplier: 1 | 2;
  phaseMultiplier: number; // 1, 1.2, 1.4, 1.6, 1.8, 2
  final: number;         // resultado inteiro final
}

export type Criterion =
  | 'placar_exato'        // 50
  | 'vencedor_e_gols'     // 35
  | 'vencedor'            // 20
  | 'empate'              // 20
  | 'errado';             // 0
```

---

## 2. Contrato das funcoes (assinaturas exatas)

```ts
// Pontos-base puros. Nao aplica multiplicador. guess null retorna base 0 / errado.
export function basePoints(guess: Guess | null, result: MatchResult): {
  base: number;
  criterion: Criterion;
};

// Multiplicador de fase. Ver tabela secao 5. Nunca lanca; fase invalida e erro de tipo.
export function phaseMultiplier(phase: Phase): number;

// Calculo completo. Ordem: base -> Brasil -> fase. Arredonda no final.
export function finalPoints(input: ScoreInput): ScoreBreakdown;
```

`finalPoints` e a unica funcao que o resto do sistema chama. `basePoints` e
`phaseMultiplier` sao exportadas apenas para teste unitario direto.

---

## 3. Regra de pontos-base (tabela de verdade)

A pontuacao NAO e cumulativa. Avalia os criterios na ordem abaixo e PARA no primeiro
que bater. So o de maior valor conta.

Ordem de avaliacao (de cima para baixo):

| # | Criterio | Condicao logica | Base |
|---|---|---|---|
| 1 | `placar_exato` | `homeGuess === homeScore && awayGuess === awayScore` | 50 |
| 2 | `vencedor_e_gols` | acertou quem venceu (ou que foi empate) E acertou o numero de gols de PELO MENOS uma das selecoes, sem ter batido o criterio 1 | 35 |
| 3 | `vencedor` | acertou apenas quem venceu, sem acertar gols de nenhuma selecao | 20 |
| 4 | `empate` | o resultado real foi empate E o palpite foi empate, mas com placar diferente (ex real 1x1, palpite 2x2) | 20 |
| 5 | `errado` | nenhum dos anteriores, ou `guess === null` | 0 |

### 3.1 Definicao precisa de "quem venceu"

Para qualquer placar, o resultado tem um de tres sinais:
- `home` vence se `homeScore > awayScore`
- `away` vence se `awayScore > homeScore`
- `draw` (empate) se `homeScore === awayScore`

O mesmo vale para o palpite. "Acertou o vencedor" significa: o sinal do palpite e
igual ao sinal do resultado.

### 3.2 Detalhamento do criterio 2 (a fonte mais comum de erro)

`vencedor_e_gols` exige DUAS coisas ao mesmo tempo:
1. sinal do palpite igual ao sinal do resultado (acertou vencedor ou empate), E
2. `homeGuess === homeScore` OU `awayGuess === awayScore` (acertou os gols de ao
   menos um lado).

Se as duas batem mas o placar inteiro tambem bate, entao o criterio 1 ja teria
parado antes. Por isso o criterio 2 so e alcancado quando acertou um lado mas nao o
outro.

Exemplo que distingue criterio 2 de criterio 3:
- Real 2x0, palpite 2x1: sinal igual (home vence), home gols batem (2===2). Criterio 2 = 35.
- Real 2x0, palpite 3x1: sinal igual (home vence), nenhum lado bate (3!=2, 1!=0). Criterio 3 = 20.

### 3.3 Por que empate tem dois criterios

Empate com placar exato cai no criterio 1 (50). Exemplo real 1x1 palpite 1x1 = 50.
Empate com placar errado cai no criterio 4 (20). Exemplo real 1x1 palpite 2x2 = 20.
Note que num empate, se voce acerta o placar de um lado voce acerta o do outro (sao
iguais), entao o criterio 2 nunca se aplica a empates: ou e exato (50) ou e so empate
(20). Nunca 35 para empate. Isto deve ser explicito no codigo e no teste.

---

## 4. Multiplicador Brasil

`brazilMultiplier = isBrazilMatch ? 2 : 1`.

Aplica-se a qualquer partida em que a selecao brasileira joga, em qualquer fase.
Multiplica os pontos-base. Aplica ANTES do multiplicador de fase.

---

## 5. Multiplicador de fase

```ts
const PHASE_MULTIPLIER: Record<Phase, number> = {
  grupos:   1,
  '32avos': 1.2,
  oitavas:  1.4,
  quartas:  1.6,
  semi:     1.8,
  terceiro: 1.8,  // disputa de 3 e 4 lugar usa o mesmo da semi
  final:    2,
};
```

---

## 6. Formula e ordem

```
final = round( base * brazilMultiplier * phaseMultiplier )
```

Ordem obrigatoria: base, depois Brasil, depois fase. A ordem so importa para deixar
explicito; matematicamente a multiplicacao comuta, mas o codigo deve seguir esta
ordem para auditoria.

### 6.1 Regra de arredondamento (travada)

Arredondar para o inteiro mais proximo. Caso .5, arredondar para cima (round half up).
Use `Math.round` do JavaScript, que ja faz half up para positivos. Todos os valores
sao positivos, entao `Math.round` e suficiente.

Justificativa: os multiplicadores 1.2, 1.4, 1.6, 1.8 podem gerar decimais. Exemplo:
35 * 1 * 1.4 = 49 (inteiro). 20 * 1 * 1.2 = 24 (inteiro). 35 * 2 * 1.8 = 126 (inteiro).
Combinacoes que geram decimal devem arredondar. O teste cobre um caso decimal explicito.

---

## 7. Tabela de verdade completa (casos de teste obrigatorios)

Todos os casos abaixo viram `it()` no scoring.test.ts. Nao pode faltar nenhum. Nao
pode adicionar regra que quebre nenhum.

### 7.1 Pontos-base puros (sem multiplicador)

| Caso | Real | Palpite | Criterio | Base |
|---|---|---|---|---|
| B1 | 2x0 | 2x0 | placar_exato | 50 |
| B2 | 2x0 | 2x1 | vencedor_e_gols | 35 |
| B3 | 2x0 | 3x1 | vencedor | 20 |
| B4 | 0x0 | 0x0 | placar_exato | 50 |
| B5 | 1x1 | 2x2 | empate | 20 |
| B6 | 1x1 | 1x1 | placar_exato | 50 |
| B7 | 2x1 | 1x2 | errado (sinal invertido) | 0 |
| B8 | 2x1 | 0x3 | errado | 0 |
| B9 | 3x1 | 3x2 | vencedor_e_gols (home bate) | 35 |
| B10 | 3x1 | 2x1 | vencedor_e_gols (away bate) | 35 |
| B11 | 0x2 | 0x1 | vencedor_e_gols (home bate, away vence) | 35 |
| B12 | 2x2 | 3x3 | empate | 20 |
| B13 | qualquer | null | errado | 0 |
| B14 | 1x0 | 0x1 | errado (inverteu vencedor) | 0 |

Atencao ao B11: real 0x2 (visitante vence), palpite 0x1 (visitante vence, home gols
batem 0===0). Sinal igual + um lado bate = criterio 2 = 35. Este caso pega o erro de
quem assume que "gols de uma selecao" so vale para o mandante.

### 7.2 Pontuacao final com multiplicadores

| Caso | Fase | Brasil | Real | Palpite | Conta | Final |
|---|---|---|---|---|---|---|
| F1 | grupos | nao | 2x0 | 3x1 | 20 x1 x1 | 20 |
| F2 | grupos | sim | 2x1 | 2x0 | 35 x2 x1 | 70 |
| F3 | oitavas | nao | 2x1 | 2x0 | 35 x1 x1,4 | 49 |
| F4 | quartas | nao | 2x0 | 2x0 | 50 x1 x1,6 | 80 |
| F5 | final | nao | 1x0 | 1x0 | 50 x1 x2 | 100 |
| F6 | oitavas | sim | 1x1 | 2x2 | 20 x2 x1,4 | 56 |
| F7 | semi | sim | 2x1 | 2x0 | 35 x2 x1,8 | 126 |
| F8 | final | sim | 2x1 | 2x1 | 50 x2 x2 | 200 |
| F9 | 32avos | nao | 1x0 | 1x0 | 50 x1 x1,2 | 60 |
| F10 | terceiro | nao | 2x1 | 2x0 | 35 x1 x1,8 | 63 |
| F11 (decimal) | 32avos | nao | 2x0 | 2x1 | 35 x1 x1,2 = 42 | 42 |
| F12 (decimal arredonda) | oitavas | nao | 1x1 | 2x2 | 20 x1 x1,4 = 28 | 28 |

Para forcar um caso de arredondamento de fato decimal, adicione:
| F13 | 32avos | nao | 3x1 | 3x2 | 35 x1 x1,2 = 42,0 | 42 |

Se nenhuma combinacao de base x mult gerar fracao .5 com os numeros atuais, crie um
teste unitario direto chamando a logica de arredondamento com um valor sintetico
(ex: garantir que round(49.5) === 50 e round(49.4) === 49) para documentar a regra.

### 7.3 Detalhamento (ScoreBreakdown) deve ser auditavel

Para o caso F8, o teste verifica o objeto inteiro:
```ts
expect(finalPoints({ guess:{homeGuess:2,awayGuess:1}, result:{homeScore:2,awayScore:1}, phase:'final', isBrazilMatch:true }))
  .toEqual({ base:50, criterion:'placar_exato', brazilMultiplier:2, phaseMultiplier:2, final:200 });
```

---

## 8. Casos de borda e regras de robustez

- `guess === null` sempre retorna base 0, criterio `errado`, final 0. Nunca lanca.
- Penalti nao conta. O `result` que chega aqui ja e o placar do tempo regulamentar ou
  prorrogacao. Esta funcao nao sabe de penalti. Quem grava o resultado (admin) e
  responsavel por inserir o placar correto. Documentar isso em comentario no topo.
- Numeros negativos no result ou guess sao entrada invalida. A funcao assume entrada
  ja validada por Zod na borda. Nao revalida, mas o teste inclui um caso garantindo
  que numeros dentro do range funcionam. Validacao de range fica em validations.ts.
- Empate nunca retorna criterio `vencedor_e_gols`. Garantir com teste (B5, B12).

---

## 9. Esqueleto de implementacao (guia, nao colar cego)

```ts
function sign(h: number, a: number): 'home' | 'away' | 'draw' {
  if (h > a) return 'home';
  if (a > h) return 'away';
  return 'draw';
}

export function basePoints(guess: Guess | null, result: MatchResult) {
  if (!guess) return { base: 0, criterion: 'errado' as Criterion };

  const exact = guess.homeGuess === result.homeScore && guess.awayGuess === result.awayScore;
  if (exact) return { base: 50, criterion: 'placar_exato' as Criterion };

  const sameSign = sign(guess.homeGuess, guess.awayGuess) === sign(result.homeScore, result.awayScore);
  const oneSideHits = guess.homeGuess === result.homeScore || guess.awayGuess === result.awayScore;
  const isDraw = sign(result.homeScore, result.awayScore) === 'draw';

  if (sameSign && oneSideHits && !isDraw) return { base: 35, criterion: 'vencedor_e_gols' as Criterion };
  if (sameSign && isDraw) return { base: 20, criterion: 'empate' as Criterion };
  if (sameSign) return { base: 20, criterion: 'vencedor' as Criterion };
  return { base: 0, criterion: 'errado' as Criterion };
}
```

Nota: no empate, `oneSideHits` com placar diferente seria falso de qualquer modo, e
com placar igual o criterio 1 ja parou. Por isso a ordem das checagens acima da o
resultado correto. Validar com os casos B5, B6, B12.

---

## 10. Checklist de verificacao da Task de scoring

Antes de marcar a Task 2.1 como done:
- [ ] Todos os casos B1..B14 passam.
- [ ] Todos os casos F1..F13 passam.
- [ ] Teste do ScoreBreakdown completo (secao 7.3) passa.
- [ ] Teste de arredondamento half up documentado.
- [ ] Nenhum acesso a banco, data do sistema ou I/O dentro de scoring.ts.
- [ ] `npm run typecheck` limpo. Zero any.
- [ ] Nenhum outro arquivo recalcula pontos.
