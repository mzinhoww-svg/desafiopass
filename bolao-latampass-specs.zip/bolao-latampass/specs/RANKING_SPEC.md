# specs/RANKING_SPEC.md

Especificacao normativa do ranking. Fonte unica da verdade. O ranking e a segunda
zona mais sensivel do produto depois da pontuacao. Ambiguidade aqui gera posicao
instavel, usuario "sumindo" da lista e reclamacao. Toda regra abaixo e determinista.
Se algo estiver indefinido, PARE e pergunte.

Aplica-se a: ranking geral (`/ranking`) e ranking de liga (`/ligas/[id]`). A logica
de ordenacao e desempate e identica nos dois; muda apenas o conjunto de usuarios
(todos vs membros da liga).

---

## 1. Fonte dos pontos

O total de um usuario e a soma de `predictions.points` de todas as suas linhas em
partidas com `status = 'encerrada'`. Calculado por query agregada no servidor. NUNCA
enviado pelo client. NUNCA somado em JavaScript no browser.

Partidas nao encerradas nao contribuem (points ainda e 0 ou irrelevante). Usar o
join com matches e filtrar status para evitar contar palpite de jogo nao apurado.

---

## 2. Ordenacao primaria

Ordenar por total de pontos, decrescente. Maior pontuacao em primeiro.

---

## 3. Criterio de desempate (TRAVADO, nao inventar outro)

Quando dois ou mais usuarios tem o mesmo total de pontos, eles OCUPAM A MESMA POSICAO
no numero exibido (ranking competition style, ver secao 4). Mas a ORDEM em que
aparecem na lista (linha de cima vs linha de baixo) precisa ser determinista e
estavel, senao a lista "pula" a cada refresh.

Ordem de criterios de desempate para a posicao na lista, nesta sequencia exata:

1. **Pontos** desc (criterio primario).
2. **Quantidade de placares exatos** desc. Quem tem mais acertos de placar exato
   (criterion = placar_exato) aparece antes. Premia precisao.
3. **Data de criacao da conta** asc (`users.created_at`). Conta mais antiga aparece
   antes. Premia quem entrou primeiro.
4. **id do usuario** asc. Criterio final de desempate puramente tecnico, garante
   ordem totalmente estavel e nunca ambigua.

O criterio 4 garante que a ordem nunca depende de acaso do banco. Dois usuarios nunca
ficam em ordem indefinida.

Nota importante: o desempate dos criterios 2, 3 e 4 afeta apenas QUEM APARECE ACIMA
de quem na lista. NAO afeta o NUMERO da posicao exibida. Tres usuarios empatados em
pontos exibem todos a mesma posicao (ver secao 4), mesmo que a lista os ordene
internamente por placares exatos.

Decisao de produto: o desempate NAO premia o segundo usuario empatado com posicao
pior no numero. Eles dividem a posicao. Isto espelha o app de referencia, onde varios
usuarios aparecem como "5". A premiacao em caso de empate na faixa premiada e tratada
fora do MVP (operacional LATAM Pass).

---

## 4. Numeracao da posicao (competition ranking, "1224")

Usar competition ranking. Empatados recebem o MESMO numero, e o proximo numero pula a
quantidade de empatados.

Exemplo canonico (vira teste):

| Ordem na lista | Usuario | Pontos | Posicao exibida |
|---|---|---|---|
| 1 | A | 1880 | 1 |
| 2 | B | 1875 | 2 |
| 3 | C | 1810 | 3 |
| 4 | D | 1810 | 3 |
| 5 | E | 1810 | 3 |
| 6 | F | 1805 | 6 |
| 7 | G | 1800 | 7 |

Tres usuarios com 1810 sao todos posicao 3. O proximo (1805) e posicao 6, nao 4.
Isto e exatamente o que aparece nas telas de referencia (varios "5" seguidos de "8").

Regra de calculo da posicao: a posicao de um usuario e 1 + (numero de usuarios com
pontuacao estritamente maior que a dele). Esta formula gera competition ranking
naturalmente e e simples de implementar em SQL com window function ou subquery.

---

## 5. Bloco "sua posicao" (usuario logado)

No topo do ranking, sempre exibir uma faixa com a posicao do usuario logado, seu
apelido e seu total, MESMO que ele esteja fora da janela visivel (ex: posicao 4200).

Edge cases enumerados:

| Situacao | O que exibir |
|---|---|
| Usuario tem pontos e esta no top visivel | Faixa no topo com sua posicao real. Linha dele na lista realcada (verde claro). |
| Usuario tem pontos mas fora do top visivel | Faixa no topo com posicao real (ex 4200). Lista mostra o top. Ele nao aparece duas vezes na lista, mas a faixa o mostra. |
| Usuario com 0 pontos (nunca pontuou) | Posicao exibida como travessao tipografico ou "sem posicao". NAO inventar posicao numerica. O app de referencia mostra "tracinho" quando pontos = 0. Texto: "Sua posicao: sem ranking ainda" e total 0. |
| Usuario nao logado (visitante) | Nao exibir a faixa pessoal. Mostrar so a lista publica e um CTA para entrar. |
| Ranking ainda inativo (nenhuma partida encerrada) | Lista vazia. Mensagem central: "O ranking ainda esta inativo." Faixa pessoal mostra 0 e sem posicao. Espelha a tela de referencia. |
| Empate na posicao do usuario | A faixa mostra a posicao compartilhada (ex 5), igual aos outros empatados. |

Regra para pontos = 0: um usuario com 0 pontos NAO recebe numero de posicao. Razao:
no MVP, dezenas de milhares podem ter 0. Numera-los e ruido e instavel. Exibir
travessao e a decisao travada, alinhada a referencia.

---

## 6. Paginacao e janela

- Carregar os primeiros 100 colocados na primeira renderizacao.
- Resto sob demanda (scroll ou botao "carregar mais"), em paginas de 50.
- A faixa pessoal e independente da paginacao. Sempre vem de uma query separada que
  calcula a posicao exata do usuario logado, sem depender de ele estar na pagina.

Edge: se o usuario esta na posicao 137 e a primeira pagina vai ate 100, a faixa
pessoal ainda mostra 137 corretamente, pois vem de query propria.

---

## 7. Contrato da camada de dados

```ts
// Uma linha do ranking exibida na lista.
export interface RankRow {
  userId: string;
  nickname: string;
  isPremium: boolean;     // para selo (V2 visual). Carregar agora, exibir depois.
  points: number;
  exactCount: number;     // placares exatos, para desempate e possivel exibicao
  position: number;       // competition ranking (1,2,3,3,3,6,...)
  isCurrentUser: boolean; // realce na lista
}

// Faixa pessoal do topo.
export interface MyRank {
  nickname: string;
  points: number;
  position: number | null; // null quando points === 0 (exibir travessao)
}

// Funcoes da camada de dados (lib/queries/ranking.ts), todas server-side.
export async function getGlobalRanking(args: {
  currentUserId: string | null;
  limit: number;   // default 100
  offset: number;  // default 0
}): Promise<RankRow[]>;

export async function getMyGlobalRank(userId: string): Promise<MyRank>;

export async function getLeagueRanking(args: {
  leagueId: string;
  currentUserId: string | null;
  limit: number;
  offset: number;
}): Promise<RankRow[]>;
```

---

## 8. SQL de referencia (Postgres)

### 8.1 Total por usuario (CTE base)

```sql
-- pontos por usuario, apenas partidas encerradas
WITH totals AS (
  SELECT
    u.id            AS user_id,
    u.nickname      AS nickname,
    u.is_premium    AS is_premium,
    u.created_at    AS created_at,
    COALESCE(SUM(p.points), 0)                                  AS points,
    COUNT(*) FILTER (WHERE pr_crit.is_exact)                    AS exact_count
  FROM users u
  LEFT JOIN predictions p ON p.user_id = u.id
  LEFT JOIN matches m     ON m.id = p.match_id AND m.status = 'encerrada'
  -- is_exact derivado: 1 quando o palpite bateu placar exato.
  -- Como points e gravado, exact_count pode vir de uma coluna criterion
  -- gravada em predictions OU recalculada. Ver nota 8.4.
  LEFT JOIN LATERAL (
    SELECT (p.home_guess = m.home_score AND p.away_guess = m.away_score) AS is_exact
  ) pr_crit ON true
  WHERE m.id IS NOT NULL  -- so conta linhas de partidas encerradas
  GROUP BY u.id, u.nickname, u.is_premium, u.created_at
)
```

### 8.2 Posicao competition ranking

```sql
SELECT
  t.*,
  CASE
    WHEN t.points = 0 THEN NULL
    ELSE 1 + (SELECT COUNT(*) FROM totals t2 WHERE t2.points > t.points)
  END AS position
FROM totals t
ORDER BY
  t.points DESC,
  t.exact_count DESC,
  t.created_at ASC,
  t.user_id ASC
LIMIT $1 OFFSET $2;
```

### 8.3 Faixa pessoal

```sql
WITH totals AS ( /* mesma CTE 8.1 */ )
SELECT
  nickname,
  points,
  CASE WHEN points = 0 THEN NULL
       ELSE 1 + (SELECT COUNT(*) FROM totals t2 WHERE t2.points > totals.points)
  END AS position
FROM totals
WHERE user_id = $1;
```

### 8.4 Nota sobre exact_count

Duas opcoes, escolher uma e documentar:
- **Opcao A (preferida):** gravar `criterion` em `predictions` na hora de pontuar.
  Entao `exact_count` e `COUNT(*) FILTER (WHERE criterion = 'placar_exato')`. Mais
  rapido, sem recomputo. Exige coluna `criterion text null` em predictions.
- **Opcao B:** derivar na query comparando guess com score (como no LATERAL acima).
  Sem coluna extra, porem recomputa em toda leitura de ranking.

Decisao travada: usar Opcao A. Adicionar coluna `criterion` em predictions, gravada
junto com points ao encerrar a partida. Atualizar ESTRUTURA.md e o schema.

### 8.5 Ranking de liga

Identico, mas a CTE totals comeca de `league_members` filtrando `league_id`:

```sql
WITH member_totals AS (
  SELECT u.id, u.nickname, u.is_premium, u.created_at,
         COALESCE(SUM(p.points),0) AS points,
         COUNT(*) FILTER (WHERE p.criterion = 'placar_exato') AS exact_count
  FROM league_members lm
  JOIN users u ON u.id = lm.user_id
  LEFT JOIN predictions p ON p.user_id = u.id
  LEFT JOIN matches m ON m.id = p.match_id AND m.status = 'encerrada'
  WHERE lm.league_id = $1
  GROUP BY u.id, u.nickname, u.is_premium, u.created_at
)
-- mesma logica de posicao e ordenacao
```

---

## 9. Casos de teste obrigatorios (ranking)

Montar com dados semeados deterministicos. Cada caso vira teste de integracao da
query ou teste unitario da funcao de posicionamento.

| Caso | Cenario | Esperado |
|---|---|---|
| R1 | A=1880, B=1875, C=1810, D=1810, E=1810, F=1805 | posicoes 1,2,3,3,3,6 |
| R2 | usuario logado em 4 com mesmo ponto de outros 2 | faixa mostra posicao compartilhada |
| R3 | usuario logado com 0 pontos | faixa position = null (travessao), nao aparece numerado |
| R4 | usuario logado fora do top 100 (posicao 137) | faixa mostra 137 via query propria; lista mostra top 100 |
| R5 | nenhuma partida encerrada | lista vazia, mensagem de inativo, faixa 0 |
| R6 | dois usuarios mesmo ponto e mesmo exact_count | desempata por created_at, ordem estavel entre refreshes |
| R7 | visitante nao logado | sem faixa pessoal, lista publica visivel |
| R8 | liga com 4 membros | ranking so dos 4, mesma logica de posicao |
| R9 | empate de pontos cruzando a fronteira de pagina (pos 100 e 101 empatados) | ambos posicao correta, sem duplicar nem sumir |
| R10 | usuario com pontos negativos | impossivel por contrato (points >= 0). Teste garante que nunca ocorre. |

R6 e o caso que mais pega bug: rodar a query duas vezes e garantir ordem identica.
R9 garante que paginacao nao corrompe competition ranking.

---

## 10. Checklist de verificacao da Task de ranking

- [ ] Casos R1..R9 passam.
- [ ] Posicao usa competition ranking (formula 1 + count de pontuacao maior).
- [ ] Desempate na ordem exata: pontos, exact_count, created_at, user_id.
- [ ] Faixa pessoal vem de query propria, funciona fora do top.
- [ ] points = 0 exibe travessao, nunca numero.
- [ ] Total sempre server-side, nunca do client.
- [ ] Coluna criterion gravada em predictions (Opcao A).
- [ ] Ordem estavel entre dois refreshes (R6).
