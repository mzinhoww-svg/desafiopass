# Task 2.5 - Resultado na UI

Cole junto com 00_PROTOCOLO.md.

## Objetivo
Exibir, em partida encerrada, o palpite do usuario, o placar real e os pontos ganhos.

## Contexto a ler antes
- prompts/00_PROTOCOLO.md
- wireframe tela 5 (palpite encerrado)
- specs/SCORING_SPEC.md (criterion, para a frase explicativa)

## Escopo exato
1. Atualizar match-card e/ou a pagina da partida para o estado encerrado: "Voce
   palpitou X x Y", "O placar foi A x B", e os pontos em verde.
2. Opcional util: frase curta explicando o criterio (ex "Acertou vencedor e gols").
   Usar o criterion gravado, sem recalcular.

## Pontos de atencao
- Nao recalcular pontos na UI. Ler points e criterion gravados.
- Verde para acerto, conforme BRANDING (estado, nao cor de marca).

## Must-haves
- [ ] Partida encerrada mostra palpite, placar real e pontos do usuario.
- [ ] Pontos lidos do banco, nao recalculados no client.

## Verificacao
Abrir uma partida encerrada com palpite e conferir os tres dados.

## Commit
feat(predictions): exibicao de resultado e pontos em partida encerrada


## Output esperado (conferir no Passo 3 - VALIDAR)
Partida encerrada exibe palpite, placar real e pontos do usuario, lidos do banco (nao recalculados no client).

## Registro no backlog (Passo 1 e Passo 4)
- Passo 1: leia .planning/backlog.md inteiro. Marque esta task como EM ANDAMENTO na
  secao 2. Copie os must-haves acima para a secao 3. Escreva o plano na secao 5.
- Passo 4: marque a task como CONCLUIDA na secao 2, marque os must-haves na secao 3 com
  evidencia, adicione decisoes novas na secao 4, e registre a linha de log na secao 5
  com o commit. So entao a task esta fechada.
