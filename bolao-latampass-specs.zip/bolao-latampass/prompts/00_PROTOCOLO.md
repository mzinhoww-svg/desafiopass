# prompts/00_PROTOCOLO.md

Protocolo obrigatorio. Leia antes de qualquer task e mantenha em contexto durante toda
a execucao. Cole este arquivo junto com o prompt da task. Ele impede alucinacao,
escopo solto, divergencia de spec e perda de estado entre sessoes.

---

## Regra de ouro

Voce nao inventa. Voce implementa o que esta especificado. Quando a especificacao nao
cobre um ponto, voce PARA e PERGUNTA. Preencher lacuna por conta propria e o erro mais
caro deste projeto.

---

## O CICLO DE EXECUCAO (obrigatorio em toda task)

Toda task passa por cinco passos, nesta ordem. Pular qualquer passo reprova a task. O
arquivo .planning/backlog.md e a memoria viva: voce LE no inicio e GRAVA no fim.

### Passo 1 - LER E PLANEJAR
- Leia .planning/backlog.md INTEIRO. Ele diz o que ja foi feito, o que foi decidido
  (secao 4) e o que esta bloqueado. Nunca comece sem isso.
- Leia este protocolo e os documentos que o prompt da task referencia (so eles, nao o
  codebase inteiro).
- Marque a task como EM ANDAMENTO na secao 2 do backlog.
- Copie os must-haves do prompt para a secao 3 do backlog.
- Escreva o PLANO (1 a 3 linhas) na secao 5 (log cronologico) do backlog e tambem na
  sua resposta: arquivos que vai criar/alterar, como cumpre cada must-have, e qualquer
  ambiguidade.
- Se houver ambiguidade, PARE, registre na secao 6 do backlog e pergunte. Nao prossiga.

### Passo 2 - EXECUTAR
- Implemente o minimo para passar nos must-haves. Sem escopo extra, sem refatorar o
  que nao foi pedido, sem abstrair cedo.
- Conforme avanca, marque os sub-itens da task como [x] na secao 3 do backlog.

### Passo 3 - VALIDAR
- Percorra cada must-have, em texto, dizendo COMO foi satisfeito.
- Rode os comandos de verificacao da task (lint, typecheck, test, build, conforme
  existirem) e confira o OUTPUT ESPERADO definido no prompt.
- Registre o resultado de cada must-have na secao 3 do backlog (passou / evidencia).

### Passo 4 - GRAVAR
- Faca o commit atomico: tipo(escopo): descricao, em minusculas.
- Mova a task para CONCLUIDA na secao 2 do backlog.
- Adicione uma linha na secao 5 (log cronologico): [data] [task] acao | resultado | commit.
- Registre qualquer decisao nova ou descoberta na secao 4 do backlog (D10, D11, ...).

### Passo 5 - ENTREGAR E PARAR
- Confirme que o OUTPUT ESPERADO da task foi produzido.
- Pare. Aguarde o ok para a proxima task. Nunca emende duas tasks no mesmo prompt.

Resumo do ciclo: ler backlog, planejar, marcar em andamento, executar marcando
sub-itens, validar contra o output esperado, gravar no backlog, commitar, entregar,
parar.

---

## As cinco leis

1. Spec manda. A verdade esta em REQUISITOS.md, ESTRUTURA.md, BRANDING.md, nos arquivos
   de specs/ (SCORING, RANKING, DATA, DESIGN) e nas decisoes ja gravadas no backlog
   secao 4. Se o codigo diverge da spec, o codigo esta errado. Se duas specs divergem,
   PARE e pergunte.
2. Uma task por vez. So a task atual do ROADMAP. Nada de V2. Ideia fora de escopo vai
   para o backlog secao 7, nunca para o codigo.
3. Lacuna gera pergunta, nao suposicao. Faltou tipo, valor ou regra de borda? Liste as
   opcoes, registre no backlog secao 6, pergunte. Nunca assuma em silencio.
4. Nada de fato inventado. Nao invente nome de lib, assinatura de API ou comportamento
   de framework. Confirme na doc oficial a sintaxe da VERSAO certa (Next 15 App Router,
   NextAuth v5, Drizzle, Tailwind v4). Nao misture App Router com Pages Router.
5. Verifique antes de declarar pronto. Rode cada must-have e confira o output esperado.
   So entao commite e marque concluida.

---

## Regras de codigo que nunca relaxam

- TypeScript estrito. Zero any sem comentario justificando.
- Toda mutacao via Server Action. Client nunca escreve no banco direto.
- Logica de pontuacao so em lib/scoring.ts. Proibido duplicar a regra.
- Total de pontos e ranking sempre por query agregada server-side. Client nunca soma.
- Prazo de palpite validado server-side, UTC vs UTC.
- Validacao Zod na borda de toda action.
- Marca e design conforme BRANDING.md e specs/DESIGN_SPEC.md: Plus Jakarta Sans, navy
  #16064F, magenta #FE3173, tokens de rank ouro/prata/bronze, Lucide para icones,
  Framer Motion, banimentos do impeccable. Sem emoji estrutural. Premio em milhas.

---

## Sinais de alerta (quando PARAR e perguntar)

Pare imediatamente se voce se pegar:
- Reescrevendo a regra de pontuacao "mais simples".
- Inventando criterio de desempate diferente do RANKING_SPEC.
- Assumindo timezone local em vez de UTC.
- Criando tabela ou coluna fora do DATA_SPEC.
- Usando API que voce nao tem certeza que existe naquela versao.
- Implementando algo marcado como V2 ou backlog.
- Introduzindo fonte nova, cor de marca nova ou asset de marca inexistente.
- Resolvendo ambiguidade da spec sem perguntar.
Em todos: descreva o conflito, registre no backlog secao 6, liste opcoes, pergunte.

---

## Formato de resposta esperado em cada task

```
LEITURA DO BACKLOG
- estado atual relevante: ...
- decisoes que afetam esta task: ...

PLANO
- arquivos: ...
- must-haves e como cumprir: ...
- output esperado: ...
- ambiguidades: ... (ou "nenhuma")

[se houver ambiguidade, registrar no backlog secao 6 e aguardar ok aqui]

IMPLEMENTACAO
[codigo]

VALIDACAO
- must-have 1: como foi satisfeito | evidencia
- must-have 2: ...
- output esperado conferido: ...
- comandos rodados e resultado: ...

GRAVACAO NO BACKLOG
- secao 2: task movida para CONCLUIDA
- secao 3: must-haves marcados
- secao 4: decisoes novas (se houver)
- secao 5: linha de log
- commit: tipo(escopo): descricao
```

---

## Contexto fixo do projeto (para nao reperguntar)

- Stack: Next.js 15 App Router, TypeScript estrito, Vercel Postgres, Drizzle, NextAuth
  v5 Credentials, Tailwind v4, deploy Vercel, repo GitHub, CI GitHub Actions.
- Dono: Aurimar Reiners, PM de Inovacoes, LATAM Pass Brasil, squad eLoyalty / New
  Business.
- MVP: palpites + pontuacao + ranking geral + ligas privadas. Jogos via seed estatico.
- Design: ver specs/DESIGN_SPEC.md. Fora do MVP: ver backlog secao 7.
