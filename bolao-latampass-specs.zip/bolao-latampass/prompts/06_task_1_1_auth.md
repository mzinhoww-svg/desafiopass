# Task 1.1 - NextAuth Credentials

Cole junto com 00_PROTOCOLO.md.

## Objetivo
Login e logout com NextAuth v5 (Credentials), sessao JWT, e middleware protegendo
rotas autenticadas e /admin.

## Contexto a ler antes
- prompts/00_PROTOCOLO.md
- ESTRUTURA.md secao "Seguranca aplicada" e "Fluxos chave"
- specs/DATA_SPEC.md secao 1 (tabela users, campo role)

## Escopo exato
1. lib/auth.ts: configuracao NextAuth v5 com Credentials provider. Confirmar na doc
   oficial a API do Auth.js v5 (difere do NextAuth v4). Sessao via JWT. Incluir role e
   id no token e na sessao.
2. app/api/auth/[...nextauth]/route.ts conforme o padrao do v5.
3. Comparar senha com bcrypt no authorize.
4. middleware.ts: proteger rotas que exigem login e proteger /admin exigindo role admin.
   Redirecionar nao autenticado para /login.
5. Helper para ler a sessao no server (getCurrentUser) usado por Server Components e
   actions.

## Pontos de atencao
- Versao: Auth.js v5, App Router. Nao usar sintaxe do v4.
- Nunca expor passwordHash na sessao.
- role no token para o middleware decidir admin sem ir ao banco.

## Fora de escopo
Tela de cadastro (Task 1.2). Login social (backlog).

## Must-haves
- [ ] Login e logout funcionam com um usuario semeado (criar um usuario de teste no seed
      ou via script).
- [ ] Sessao traz id e role.
- [ ] middleware bloqueia /admin para nao admin e rotas logadas para visitante.

## Verificacao
Logar com usuario de teste, acessar rota protegida, tentar /admin como user e como admin.

## Commit
feat(auth): nextauth v5 credentials, sessao jwt e middleware


## Output esperado (conferir no Passo 3 - VALIDAR)
Login e logout funcionam com usuario de teste. Sessao traz id e role. middleware bloqueia /admin para nao-admin e rotas logadas para visitante.

## Registro no backlog (Passo 1 e Passo 4)
- Passo 1: leia .planning/backlog.md inteiro. Marque esta task como EM ANDAMENTO na
  secao 2. Copie os must-haves acima para a secao 3. Escreva o plano na secao 5.
- Passo 4: marque a task como CONCLUIDA na secao 2, marque os must-haves na secao 3 com
  evidencia, adicione decisoes novas na secao 4, e registre a linha de log na secao 5
  com o commit. So entao a task esta fechada.
