# Task 0.3 - Banco e ORM

Cole junto com 00_PROTOCOLO.md.

## Objetivo
Provisionar Vercel Postgres, configurar Drizzle e criar o schema completo. Migracao
aplica e cria as tabelas.

## Contexto a ler antes
- prompts/00_PROTOCOLO.md
- specs/DATA_SPEC.md secao 1 (schema literal) e 1.1 (decisoes travadas)
- ESTRUTURA.md secao "Modelo de dados" e "Variaveis de ambiente"

## Escopo exato
1. lib/db.ts: client Drizzle conectado ao Vercel Postgres. Confirmar na doc oficial a
   forma atual de conectar Drizzle ao Vercel Postgres (driver e helper corretos).
2. drizzle/schema.ts: copiar EXATAMENTE o schema de DATA_SPEC secao 1, incluindo a
   coluna criterion em predictions, todos os indices, uniques e cascades.
3. drizzle.config.ts configurado.
4. Scripts db:generate e db:migrate funcionando.
5. .env.example preenchido com as chaves de DATA_SPEC e ESTRUTURA.

## Pontos de atencao (nao errar)
- kickoffAt withTimezone true.
- unique (user_id, match_id) em predictions.
- coluna criterion text null em predictions (necessaria para o ranking, RANKING_SPEC 8.4).
- onDelete cascade onde DATA_SPEC indica.
- Nenhuma coluna de total de pontos. Total e sempre agregado.

## Fora de escopo
Seed de dados (Task 0.4). Queries de ranking (Slice 3).

## Must-haves
- [ ] Schema bate exatamente com DATA_SPEC secao 1.
- [ ] npm run db:generate gera a migracao.
- [ ] npm run db:migrate aplica e cria todas as tabelas no Postgres.
- [ ] Indices e constraints criados (verificar no banco ou no Drizzle Studio).

## Verificacao
Rodar db:generate e db:migrate. Inspecionar as tabelas. Confirmar criterion e o unique.

## Commit
feat(db): schema drizzle completo e migracao inicial


## Output esperado (conferir no Passo 3 - VALIDAR)
Migracao aplicada no Postgres com todas as tabelas, indices e a coluna criterion em predictions. `npm run db:migrate` conclui sem erro. Tabelas visiveis no Drizzle Studio.

## Registro no backlog (Passo 1 e Passo 4)
- Passo 1: leia .planning/backlog.md inteiro. Marque esta task como EM ANDAMENTO na
  secao 2. Copie os must-haves acima para a secao 3. Escreva o plano na secao 5.
- Passo 4: marque a task como CONCLUIDA na secao 2, marque os must-haves na secao 3 com
  evidencia, adicione decisoes novas na secao 4, e registre a linha de log na secao 5
  com o commit. So entao a task esta fechada.
