# Task 5.3 - QA e responsivo

Cole junto com 00_PROTOCOLO.md.

## Objetivo
Revisar todas as telas no mobile, garantir contraste, foco e labels, e deixar
lint, typecheck e test verdes.

## Contexto a ler antes
- prompts/00_PROTOCOLO.md
- BRANDING.md secao "Acessibilidade"
- REQUISITOS.md secao 12 (nao funcionais)

## Escopo exato
1. Revisar cada tela em viewport mobile (coluna unica, area de toque 44px).
2. Conferir contraste dos pares de cor, foco visivel magenta, labels em inputs.
3. Garantir lint, typecheck e test sem erro. Remover any injustificado.
4. Corrigir qualquer overflow ou quebra de layout.

## Must-haves
- [ ] Navegacao completa no mobile sem quebra.
- [ ] Contraste, foco e labels ok.
- [ ] lint, typecheck e test verdes.

## Verificacao
Percorrer o fluxo ponta a ponta no mobile. Rodar os tres comandos.

## Commit
chore(qa): ajustes de responsivo, acessibilidade e checks verdes


## Output esperado (conferir no Passo 3 - VALIDAR)
Fluxo completo navegavel no mobile sem quebra. Contraste, foco e labels ok. lint, typecheck e test verdes. Checklist anti-slop do DESIGN_SPEC secao 7 aprovado.

## Registro no backlog (Passo 1 e Passo 4)
- Passo 1: leia .planning/backlog.md inteiro. Marque esta task como EM ANDAMENTO na
  secao 2. Copie os must-haves acima para a secao 3. Escreva o plano na secao 5.
- Passo 4: marque a task como CONCLUIDA na secao 2, marque os must-haves na secao 3 com
  evidencia, adicione decisoes novas na secao 4, e registre a linha de log na secao 5
  com o commit. So entao a task esta fechada.
