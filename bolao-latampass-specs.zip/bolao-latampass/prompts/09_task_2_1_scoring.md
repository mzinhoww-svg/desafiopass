# Task 2.1 - Logica de pontuacao (a mais critica do projeto)

Cole junto com 00_PROTOCOLO.md. Esta task exige rigor maximo. A pontuacao errada
contamina ranking e premio. Implemente a spec ao pe da letra. Nao simplifique a regra.

## Objetivo
Implementar `lib/scoring.ts` como funcao pura e cobrir `lib/scoring.test.ts` com TODOS
os casos de teste da spec. Esta task vem ANTES de qualquer UI de palpite.

## Contexto a ler antes (obrigatorio, inteiro)
- prompts/00_PROTOCOLO.md
- specs/SCORING_SPEC.md (este e o contrato. Leia integralmente. Cada secao importa.)

## Escopo exato
1. lib/scoring.ts com os tipos da SCORING_SPEC secao 1 copiados exatamente.
2. As funcoes basePoints, phaseMultiplier e finalPoints com as assinaturas da secao 2.
3. A regra de pontos-base da secao 3 (tabela de verdade, ordem de avaliacao, parada no
   primeiro criterio). Atencao especial a secao 3.2 (criterio vencedor_e_gols) e 3.3
   (empate nunca e vencedor_e_gols).
4. Multiplicador Brasil (secao 4) e de fase (secao 5, objeto PHASE_MULTIPLIER exato).
5. Formula e ordem da secao 6, com arredondamento half up (Math.round) da secao 6.1.
6. Retornar ScoreBreakdown completo e auditavel (secao 7.3).
7. Comentario no topo do arquivo: penalti nao conta, entrada assumida valida, regra
   existe so aqui.

## Casos de teste que NAO podem faltar (SCORING_SPEC secao 7)
- Base puros B1 a B14. Atencao a B11 (visitante vence, gols do mandante batem) e a B5,
  B6, B12 (empates).
- Finais com multiplicador F1 a F13. Confirmar F8 = 200 (final, Brasil, placar exato).
- Teste do ScoreBreakdown inteiro para F8 (secao 7.3).
- Teste de arredondamento half up documentando round(49.5)=50 e round(49.4)=49.

## Proibicoes especificas desta task
- Proibido recalcular pontos em qualquer outro arquivo. So aqui.
- Proibido I/O, acesso a banco ou leitura de data do sistema dentro de scoring.ts.
- Proibido alterar os valores da tabela de pontos ou dos multiplicadores.
- Proibido empate retornar criterio vencedor_e_gols.
- Se algum caso de teste da spec parecer contraditorio, PARE e pergunte. Nao ajuste a
  regra para o teste passar.

## Must-haves (verificar um a um, em texto, no relatorio de verificacao)
- [ ] Tipos identicos a SCORING_SPEC secao 1.
- [ ] basePoints cobre os 5 criterios na ordem correta.
- [ ] finalPoints aplica base, Brasil, fase, nessa ordem, com round.
- [ ] Todos os casos B1..B14 passam.
- [ ] Todos os casos F1..F13 passam.
- [ ] ScoreBreakdown de F8 confere objeto inteiro.
- [ ] Arredondamento half up documentado em teste.
- [ ] Nenhum acesso a banco/data/IO no modulo. Zero any. typecheck limpo.

## Verificacao
Rodar npm run test e colar o resultado mostrando todos os casos verdes. Rodar
typecheck. Confirmar que nenhum outro arquivo importa logica de pontos duplicada.

## Commit
feat(scoring): pontos base, multiplicadores e suite de testes completa


## Output esperado (conferir no Passo 3 - VALIDAR)
lib/scoring.ts puro e lib/scoring.test.ts com todos os casos B1 a B14 e F1 a F13 verdes. `npm run test` mostra todos os casos passando. typecheck limpo, zero any. Nenhum outro arquivo recalcula pontos.

## Registro no backlog (Passo 1 e Passo 4)
- Passo 1: leia .planning/backlog.md inteiro. Marque esta task como EM ANDAMENTO na
  secao 2. Copie os must-haves acima para a secao 3. Escreva o plano na secao 5.
- Passo 4: marque a task como CONCLUIDA na secao 2, marque os must-haves na secao 3 com
  evidencia, adicione decisoes novas na secao 4, e registre a linha de log na secao 5
  com o commit. So entao a task esta fechada.
