# Task 2.4 - Admin encerra partida e pontua

Cole junto com 00_PROTOCOLO.md.

## Objetivo
Painel admin para inserir o placar real, que dispara o calculo de pontos de todos os
palpites da partida. Operacao idempotente.

## Contexto a ler antes
- prompts/00_PROTOCOLO.md
- wireframe tela 12 (Admin)
- specs/SCORING_SPEC.md (finalPoints e o ScoreBreakdown)
- specs/RANKING_SPEC.md secao 8.4 (gravar criterion junto com points, Opcao A)
- specs/DATA_SPEC.md secao 2 (adminResultSchema)
- ESTRUTURA.md "Encerrar partida e pontuar (admin)"

## Escopo exato
1. app/admin/page.tsx: lista de partidas (protegida por role admin no middleware e
   revalidada na action).
2. app/admin/partidas/[id]/page.tsx: form para inserir homeScore e awayScore e marcar
   status encerrada.
3. app/actions/admin.ts Server Action:
   - revalidar role admin,
   - validar com adminResultSchema,
   - gravar placar e status encerrada,
   - buscar todos os predictions da partida,
   - para cada um, chamar finalPoints (passando guess, result, phase, isBrazilMatch) e
     gravar points E criterion na linha,
   - operacao idempotente: reencerrar a mesma partida recalcula sem somar em dobro
     (sobrescreve points, nao acumula).

## Pontos de atencao
- isBrazilMatch derivado de home_code/away_code === 'BRA'.
- phase vem da partida.
- Gravar criterion e essencial para o exact_count do ranking (RANKING_SPEC 8.4).
- Idempotencia: o calculo sempre sobrescreve points a partir do palpite e do resultado
  atual. Nunca incrementa.
- Palpite null (usuario sem palpite) nao existe como linha; apenas usuarios que
  palpitaram tem prediction. Quem nao palpitou simplesmente nao pontua.

## Must-haves
- [ ] So admin acessa e executa.
- [ ] Inserir resultado grava points e criterion corretos em todos os palpites.
- [ ] Reencerrar a partida nao duplica pontos (idempotente).
- [ ] Pontos batem com a SCORING_SPEC para casos conhecidos.

## Verificacao
Com dados semeados, inserir um placar e conferir points de alguns palpites contra a
tabela de verdade do scoring. Reencerrar e confirmar que nao dobrou.

## Commit
feat(admin): encerrar partida e pontuar palpites de forma idempotente


## Output esperado (conferir no Passo 3 - VALIDAR)
Admin insere placar e grava points e criterion corretos em todos os palpites da partida. Reencerrar nao duplica (idempotente). Pontos batem com SCORING_SPEC.

## Registro no backlog (Passo 1 e Passo 4)
- Passo 1: leia .planning/backlog.md inteiro. Marque esta task como EM ANDAMENTO na
  secao 2. Copie os must-haves acima para a secao 3. Escreva o plano na secao 5.
- Passo 4: marque a task como CONCLUIDA na secao 2, marque os must-haves na secao 3 com
  evidencia, adicione decisoes novas na secao 4, e registre a linha de log na secao 5
  com o commit. So entao a task esta fechada.
