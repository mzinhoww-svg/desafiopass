# Task 3.1 - Ranking geral

Cole junto com 00_PROTOCOLO.md. Zona sensivel. Siga o RANKING_SPEC ao pe da letra,
em especial o desempate e o tratamento de pontos zero.

## Objetivo
Tela /ranking com ordenacao por pontos, competition ranking, desempate deterministico,
e faixa pessoal do usuario logado que funciona mesmo fora do top.

## Contexto a ler antes (inteiro)
- prompts/00_PROTOCOLO.md
- specs/RANKING_SPEC.md (contrato completo: ordenacao, desempate, competition ranking,
  faixa pessoal, edge cases, SQL de referencia)
- wireframe tela 6 (Ranking)

## Escopo exato
1. lib/queries/ranking.ts: getGlobalRanking e getMyGlobalRank (assinaturas da
   RANKING_SPEC secao 7). Usar o SQL de referencia da secao 8 (CTE de totais,
   competition ranking, desempate na ordem exata: pontos, exact_count, created_at,
   user_id). exact_count via coluna criterion (Opcao A).
2. app/ranking/page.tsx Server Component: faixa pessoal no topo (via getMyGlobalRank) e
   lista (via getGlobalRanking), top 100 inicial.
3. components/ranking-row.tsx: posicao com badge para top 3, apelido, pontos, e realce
   verde para a linha do usuario logado.
4. Tratar todos os edge cases da secao 5 e 9.

## Edge cases obrigatorios (RANKING_SPEC secao 9)
- R1 competition ranking (1,2,3,3,3,6).
- R3 usuario com 0 pontos: faixa position null, exibir travessao, nunca numero.
- R4 usuario fora do top 100: faixa mostra posicao real via query propria.
- R5 nenhuma partida encerrada: lista vazia, mensagem de inativo, faixa 0.
- R6 dois usuarios mesmo ponto e mesmo exact_count: ordem estavel entre refreshes.
- R7 visitante nao logado: sem faixa pessoal.
- R9 empate cruzando fronteira de pagina: sem duplicar nem sumir.

## Proibicoes
- Nunca somar total no client. Sempre query agregada server-side.
- Nunca inventar criterio de desempate diferente do especificado.
- Pontos zero nunca recebem numero de posicao.

## Must-haves
- [ ] Ordena por pontos desc com competition ranking (R1).
- [ ] Desempate na ordem exata da spec, estavel entre refreshes (R6).
- [ ] Faixa pessoal funciona fora do top (R4) e mostra travessao com 0 pontos (R3).
- [ ] Lista vazia trata ranking inativo (R5).
- [ ] Linha do usuario realcada.

## Verificacao
Semear cenarios R1, R3, R4, R5, R6 e conferir. Rodar a query duas vezes para confirmar
ordem identica (R6).

## Commit
feat(ranking): ranking geral com competition ranking e desempate deterministico


## Output esperado (conferir no Passo 3 - VALIDAR)
Tela /ranking ordena por pontos com competition ranking (1,2,3,3,3,6), desempate deterministico estavel entre refreshes, faixa pessoal funcionando fora do top, travessao para pontos zero, mensagem de inativo quando vazio.

## Registro no backlog (Passo 1 e Passo 4)
- Passo 1: leia .planning/backlog.md inteiro. Marque esta task como EM ANDAMENTO na
  secao 2. Copie os must-haves acima para a secao 3. Escreva o plano na secao 5.
- Passo 4: marque a task como CONCLUIDA na secao 2, marque os must-haves na secao 3 com
  evidencia, adicione decisoes novas na secao 4, e registre a linha de log na secao 5
  com o commit. So entao a task esta fechada.
