# Task 1.2 - Cadastro

Cole junto com 00_PROTOCOLO.md.

## Objetivo
Tela e Server Action de cadastro com apelido unico, hash bcrypt, confirmacao 16+ e
aceite de termos.

## Contexto a ler antes
- prompts/00_PROTOCOLO.md
- specs/DATA_SPEC.md secao 2 (signupSchema Zod)
- BRANDING.md (primitivos de input e botao)
- wireframe tela 2 (Cadastro) para layout

## Escopo exato
1. app/(auth)/cadastro/page.tsx com os campos: email, senha, apelido, checkbox 16+,
   checkbox aceite. Usar os primitivos de UI da Task 0.2.
2. app/actions/auth.ts Server Action de cadastro:
   - validar com signupSchema (DATA_SPEC 2),
   - checar apelido unico e email unico,
   - hash bcrypt da senha,
   - inserir usuario com role user, is_premium false,
   - em caso de apelido/email duplicado, retornar erro claro para a UI.
3. Apos cadastro, logar o usuario ou redirecionar para login (escolher e documentar).

## Pontos de atencao
- isAdult e acceptTerms sao literal true no Zod. Sem aceite, nao cadastra.
- Mensagem de apelido duplicado precisa ser explicita ("Apelido ja em uso").
- Nunca gravar senha em texto plano.

## Fora de escopo
Recuperacao de senha (backlog). Edicao de perfil (Task 1.3).

## Must-haves
- [ ] Cadastro cria usuario com senha em hash.
- [ ] Apelido duplicado bloqueado com mensagem clara.
- [ ] Sem confirmacao 16+ ou aceite, cadastro falha na validacao.

## Verificacao
Cadastrar usuario novo. Tentar apelido repetido. Tentar sem marcar os checkboxes.

## Commit
feat(auth): cadastro com apelido unico, bcrypt e aceite


## Output esperado (conferir no Passo 3 - VALIDAR)
Tela /cadastro cria usuario com senha em hash bcrypt. Apelido duplicado bloqueado com mensagem. Sem 16+ ou aceite, validacao falha.

## Registro no backlog (Passo 1 e Passo 4)
- Passo 1: leia .planning/backlog.md inteiro. Marque esta task como EM ANDAMENTO na
  secao 2. Copie os must-haves acima para a secao 3. Escreva o plano na secao 5.
- Passo 4: marque a task como CONCLUIDA na secao 2, marque os must-haves na secao 3 com
  evidencia, adicione decisoes novas na secao 4, e registre a linha de log na secao 5
  com o commit. So entao a task esta fechada.
