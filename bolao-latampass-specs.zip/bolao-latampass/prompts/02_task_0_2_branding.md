# Task 0.2 - Sistema de design LATAM Pass Elevate (refinado pelas skills)

Cole junto com 00_PROTOCOLO.md. Esta task aplica a identidade Elevate, nao so tokens
basicos. Segue a sequencia de skills definida no DESIGN_SPEC.

## Objetivo
Implementar o sistema de design do produto seguindo o LATAM Pass Elevate Design System:
paleta Elevate oficial (indigo/rosa/teal/lima/roxo), Plus Jakarta Sans, regra de cor
60.30.10 com acento por fundo (rosa em claro, teal em escuro), tokens de ranking
ouro/prata/bronze, motion com Framer Motion, icones Lucide, primitivos de UI e header. A
home passa a ter a identidade Elevate.

## Fonte de marca
LLM_SYSTEM_GUIDE.md (Elevate Design System) e a fonte unica de cor e fonte. O
DESIGN_SPEC.md traduz esse sistema de slides para o app mobile. O arquivo de tokens ja
esta pronto em reference-code/styles/tokens.css. Esta task copia esse arquivo e constroi
os componentes sobre ele.

## Sequencia de skills (ordem obrigatoria)
1. impeccable: governa o rigor. Aplique os banimentos absolutos e a verificacao de
   contraste e motion. Use o checklist anti-slop do DESIGN_SPEC secao 7.
2. tripled-ui: fornece os padroes de codigo (Framer Motion para entrada e scroll reveal,
   Lucide para icones) e qualidade de producao.
3. ui-ux-pro-max: fornece a estetica atletica (peso, escala oversized) e os tokens de
   rank ouro/prata/bronze, ja consolidados no DESIGN_SPEC.

## Contexto a ler antes (inteiro)
- prompts/00_PROTOCOLO.md
- LLM_SYSTEM_GUIDE.md (Elevate Design System: paleta, fonte, 60.30.10, claro vs escuro)
- specs/DESIGN_SPEC.md (documento mestre desta task; traduz Elevate para o app)
- reference-code/styles/tokens.css (tokens prontos)

## Escopo exato
1. Copiar reference-code/styles/tokens.css para app/styles/tokens.css e importar no
   app/globals.css. Expor as cores no bloco @theme inline do Tailwind v4 (indigo, rose,
   teal, lime, purple, cloud, paper, ink, muted, e os rank-gold/silver/bronze).
2. Plus Jakarta Sans via next/font (pesos 400, 500, 700, 800), aplicada no body com
   fallback system-ui. Aplicar a escala tipografica do DESIGN_SPEC secao 3 (peso 800 em
   titulos e numeros, tracking negativo em titulos grandes, caixa alta em kickers,
   escala oversized para placar e pontos).
3. Instalar e configurar Framer Motion e Lucide React. Confirmar versoes compativeis.
4. components/brand-bar.tsx: barra gradiente Elevate (--grad), para borda inferior de
   header e quebras.
5. components/header.tsx: superficie indigo, titulo caixa alta peso 800, simbolo de
   marca, barra gradiente na borda inferior. Acento de destaque no header em teal (fundo
   escuro). Asa decorativa Elevate (SVG inline, opacidade 0.14 a 0.18) opcional so na
   home.
6. components/motion/: um wrapper de entrada de tela (fade + translate, ease-out) e um
   de scroll reveal (useInView once), ambos com alternativa reduced-motion. Conforme
   DESIGN_SPEC secao 4.
7. components/ui/: botao (primario rosa em fundo claro; variante para fundo escuro usa
   teal), input com label, card (superficie paper), pill (selo), todos com os tokens
   Elevate. Icones via Lucide quando houver icone.
8. Atualizar app/page.tsx para demonstrar header, um card, um botao primario, um selo, a
   animacao de entrada e o acento correto por fundo, validando o sistema visualmente.

## Banimentos (impeccable + Elevate, conferir antes de entregar)
Sem side-stripe border, sem gradient text, sem glassmorphism decorativo, sem eyebrow
tracado em toda secao, sem grid de cards identicos, sem fundo cream/sand. Sem emoji
estrutural. Regra Elevate: no maximo 1 acento por superficie; sem parede inteira rosa ou
teal; acento certo para o fundo. Contraste body >= 4.5:1. Foco visivel (rosa em claro,
teal em escuro). reduced-motion respeitado.

## Fora de escopo
Telas reais (Tasks seguintes). Logica. Banco.

## Must-haves
- [ ] globals.css importa tokens.css; Tailwind expoe bg-indigo, text-rose, text-teal e
      os tokens de rank.
- [ ] Plus Jakarta Sans com a escala e o tracking do DESIGN_SPEC aplicados.
- [ ] Framer Motion e Lucide instalados e usados (animacao de entrada e um icone).
- [ ] Header (indigo + barra gradiente), primitivos (botao, input, card, pill) e barra
      gradiente prontos, com acento por fundo correto.
- [ ] Checklist anti-slop do DESIGN_SPEC secao 7 aprovado na home de demonstracao.

## Verificacao
Abrir a home. Conferir paleta Elevate, Jakarta, tracking, gradiente, acento por fundo
(rosa no claro, teal no escuro), animacao de entrada e um icone Lucide. Inspecionar foco
por teclado. Rodar o checklist anti-slop item a item.

## Commit
feat(design): sistema de design latam pass elevate, motion e icones

## Output esperado (conferir no Passo 3 - VALIDAR)
Home de demonstracao com a identidade Elevate: header indigo com barra gradiente e asa,
titulo em Plus Jakarta Sans peso 800 com tracking atletico, botao rosa em fundo claro,
selo, card sem side-stripe, animacao de entrada suave e um icone Lucide. globals.css
expoe todos os tokens Elevate. Checklist anti-slop aprovado.

## Registro no backlog (Passo 1 e Passo 4)
- Passo 1: leia .planning/backlog.md inteiro. Marque esta task como EM ANDAMENTO na
  secao 2. Copie os must-haves acima para a secao 3. Escreva o plano na secao 5.
- Passo 4: marque a task como CONCLUIDA na secao 2, marque os must-haves na secao 3 com
  evidencia, adicione decisoes novas na secao 4, e registre a linha de log na secao 5
  com o commit.
