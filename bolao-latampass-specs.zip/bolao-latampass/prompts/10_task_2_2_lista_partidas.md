# Task 2.2 - Lista de partidas

Cole junto com 00_PROTOCOLO.md.

## Objetivo
Tela /partidas listando jogos por fase, com selo de fase, selo Brasil e estado do
palpite (sem palpite, palpitado, encerrado com pontos).

## Contexto a ler antes
- prompts/00_PROTOCOLO.md
- wireframe tela 3 (Partidas)
- BRANDING.md (match-card, selos/pills)
- specs/DATA_SPEC.md secao 3 (status e regra de prazo, para o estado do card)

## Escopo exato
1. app/partidas/page.tsx Server Component. Carrega matches do banco, agrupados por fase
   na ordem do torneio. Para o usuario logado, carrega o palpite existente de cada jogo.
2. components/match-card.tsx: selecoes (bandeira + codigo), selo de fase com o
   multiplicador (ex "Oitavas x1,4"), selo magenta "x2 Brasil" quando for jogo do
   Brasil, e o estado:
   - agendada sem palpite: chamada para palpitar,
   - agendada com palpite: mostra "Voce palpitou X x Y",
   - encerrada: mostra "Placar: A x B" e os pontos do usuario em verde.
3. Cada card linka para /partidas/[id].

## Pontos de atencao
- O selo de fase mostra o multiplicador correto (vem de PHASE_MULTIPLIER do scoring).
- Jogo do Brasil identificado por home_code === 'BRA' ou away_code === 'BRA'.
- Horario exibido em Brasilia via formatBrasilia (DATA_SPEC 3.2), dado UTC no banco.

## Fora de escopo
Submissao do palpite (Task 2.3). Calculo de pontos (Task 2.4).

## Must-haves
- [ ] Lista exibe os jogos do seed agrupados por fase.
- [ ] Selo de fase e selo Brasil corretos.
- [ ] Estado do card reflete sem palpite, palpitado e encerrado.
- [ ] Horario em Brasilia.

## Verificacao
Abrir /partidas logado. Conferir selos, horarios e estados. Verificar um jogo do Brasil.

## Commit
feat(matches): lista de partidas por fase com selos e estado do palpite


## Output esperado (conferir no Passo 3 - VALIDAR)
Tela /partidas lista jogos do seed por fase, com selo de fase, selo x2 Brasil e estado do palpite (sem palpite, palpitado, encerrado). Horario em Brasilia.

## Registro no backlog (Passo 1 e Passo 4)
- Passo 1: leia .planning/backlog.md inteiro. Marque esta task como EM ANDAMENTO na
  secao 2. Copie os must-haves acima para a secao 3. Escreva o plano na secao 5.
- Passo 4: marque a task como CONCLUIDA na secao 2, marque os must-haves na secao 3 com
  evidencia, adicione decisoes novas na secao 4, e registre a linha de log na secao 5
  com o commit. So entao a task esta fechada.
