# Task 0.4 - Seed Copa 2026 (chaveamento real + bandeiras SVG)

Cole junto com 00_PROTOCOLO.md.

## Objetivo
Popular selecoes e jogos do mata-mata da Copa 2026 a partir de um seed estatico real.
Bandeiras como assets SVG. Sem API externa.

## Codigo pronto
O seed ja foi construido a partir do chaveamento real (ge.globo.com) e esta em
reference-code/lib/data/copa2026.ts. As bandeiras SVG reais estao em
reference-code/public/flags/ e o componente de bandeira em reference-code/components/
flag.tsx. Esta task integra esses arquivos ao projeto e escreve o script de seed.

## Contexto a ler antes
- prompts/00_PROTOCOLO.md
- specs/DATA_SPEC.md secao 6 (regras do seed) e secao 1 (tabela teams com flag_code)
- specs/SCORING_SPEC.md secao 1 (fases validas)
- reference-code/lib/data/copa2026.ts e reference-code/public/flags/README.md

## Escopo exato
1. Copiar reference-code/lib/data/copa2026.ts para lib/data/copa2026.ts. Ele exporta
   teams (com flagCode), matches (32 partidas: 16 trinta-e-dois-avos reais, 8 oitavas,
   4 quartas, 2 semis, terceiro, final) e advancement (mapa de avanco do chaveamento).
2. Copiar a pasta reference-code/public/flags/ inteira para public/flags/ (32 SVGs).
3. Copiar reference-code/components/flag.tsx para components/flag.tsx.
4. Script de seed (db:seed): le copa2026.ts, converte kickoffAt (string ISO UTC) para
   Date, insere teams e depois matches. Idempotente (upsert por code e por id).
5. A coluna do banco e flag_code (DATA_SPEC secao 1). Mapear teams[].flagCode para ela.

## Pontos de atencao
- Inserir teams antes de matches (FK home_code, away_code).
- status inicial agendada, homeScore e awayScore null.
- Brasil x Japao (R32-09) exercita o multiplicador x2. Final (FN-01) exercita x2 de fase.
- Placeholders de avanco (W_R32_1, etc) tem flagCode vazio; o componente Flag mostra
  escudo neutro. Nao usar emoji em nenhum caso.
- Horarios ja estao em UTC no seed (Brasilia +3). Nao reconverter.

## Fora de escopo
Avanco dinamico do chaveamento (V2, usar advancement so como referencia). Resultados
(entram via admin, Slice 2).

## Must-haves
- [ ] teams e matches populados via db:seed, com flag_code preenchido.
- [ ] 32 partidas cobrindo 32avos, oitavas, quartas, semi, terceiro e final.
- [ ] Bandeiras renderizam como SVG real (sem emoji) via componente Flag.
- [ ] Brasil x Japao presente. Seed idempotente (rodar 2x nao duplica).

## Verificacao
Rodar db:seed. Conferir contagem (32 selecoes reais, 32 partidas). Renderizar uma tela
de teste com o componente Flag e confirmar SVG real. Confirmar R32-09 (Brasil) e FN-01.

## Commit
feat(seed): chaveamento real copa 2026 com bandeiras svg

## Output esperado (conferir no Passo 3 - VALIDAR)
db:seed popula 32 selecoes (com flag_code) e 32 partidas reais do mata-mata, de 32avos
ate a final, com Brasil x Japao e bandeiras SVG reais renderizando via componente Flag.
Rodar 2x nao duplica.

## Registro no backlog (Passo 1 e Passo 4)
- Passo 1: leia .planning/backlog.md inteiro. Marque esta task como EM ANDAMENTO na
  secao 2. Copie os must-haves acima para a secao 3. Escreva o plano na secao 5.
- Passo 4: marque a task como CONCLUIDA na secao 2, marque os must-haves na secao 3 com
  evidencia, adicione decisoes novas na secao 4, e registre a linha de log na secao 5
  com o commit.
