# Task 2.3 - Registrar palpite (com trava de prazo)

Cole junto com 00_PROTOCOLO.md.

## Objetivo
Tela /partidas/[id] com input de placar e Server Action que faz upsert do palpite,
validando o prazo server-side.

## Contexto a ler antes
- prompts/00_PROTOCOLO.md
- wireframe telas 4 (palpite) e 5 (encerrado)
- specs/DATA_SPEC.md secao 2 (scoreSchema) e secao 3 (prazo, timezone, edge cases)
- BRANDING.md (score-input)

## Escopo exato
1. app/partidas/[id]/page.tsx: carrega a partida e o palpite existente. Decide se o
   formulario fica editavel pela condicao canonica: status agendada E isPredictionOpen.
   Se encerrada, mostra resultado (reaproveita layout da tela 5). Se prazo passou, trava.
2. components/score-input.tsx: dois campos numericos 0..20 com bandeiras.
3. app/actions/palpite.ts Server Action:
   - validar com scoreSchema (range 0..20),
   - revalidar prazo server-side comparando new Date() UTC com kickoffAt (DATA_SPEC 3.1),
   - upsert usando o unique (user_id, match_id) com onConflictDoUpdate, atualizando
     updatedAt. Vale o ultimo palpite.
   - se prazo encerrado, recusar com mensagem clara.

## Edge cases obrigatorios (DATA_SPEC 3.3)
- Submit antes do kickoff: aceita.
- Submit no instante do kickoff (now === kickoff): recusa (condicao estritamente <).
- Submit apos kickoff: recusa.
- Edicao antes do prazo: aceita, vale o ultimo.
- Edicao apos prazo: recusa server-side mesmo se a UI tentar.
- Status ao_vivo ou encerrada: nunca permite palpite.

## Proibicoes
- Nunca validar prazo so no client. A validacao que conta e a do servidor.
- Nunca gravar horario local. Comparacao UTC vs UTC.

## Must-haves
- [ ] Palpite salva e edita antes do prazo (vale o ultimo).
- [ ] Formulario trava no kickoff e depois.
- [ ] Validacao de range 0..20.
- [ ] Upsert respeita um palpite por partida.

## Verificacao
Palpitar, editar, e simular prazo (ajustar kickoff de teste no passado) para confirmar a
trava server-side.

## Commit
feat(predictions): registrar e editar palpite com trava de prazo server-side


## Output esperado (conferir no Passo 3 - VALIDAR)
Tela /partidas/[id] salva e edita palpite antes do prazo (vale o ultimo), trava no kickoff e depois. Range 0 a 20 validado. Upsert respeita um palpite por partida.

## Registro no backlog (Passo 1 e Passo 4)
- Passo 1: leia .planning/backlog.md inteiro. Marque esta task como EM ANDAMENTO na
  secao 2. Copie os must-haves acima para a secao 3. Escreva o plano na secao 5.
- Passo 4: marque a task como CONCLUIDA na secao 2, marque os must-haves na secao 3 com
  evidencia, adicione decisoes novas na secao 4, e registre a linha de log na secao 5
  com o commit. So entao a task esta fechada.
