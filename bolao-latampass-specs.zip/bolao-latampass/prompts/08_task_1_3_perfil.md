# Task 1.3 - Perfil

Cole junto com 00_PROTOCOLO.md.

## Objetivo
Tela de perfil com apelido, time do coracao e total de pontos. Editar apelido e time.

## Contexto a ler antes
- prompts/00_PROTOCOLO.md
- wireframe tela 10 (Perfil)
- specs/RANKING_SPEC.md secao 5 (faixa pessoal, para o total e posicao)

## Escopo exato
1. app/perfil/page.tsx: Server Component. Mostra apelido, time do coracao e total de
   pontos do usuario logado (e posicao, reusando a logica da faixa pessoal do ranking,
   que pode ja existir ou ser criada aqui de forma simples).
2. Edicao de apelido (mantendo a regra de unicidade) e de time do coracao via Server
   Action em app/actions (pode ficar em auth.ts ou um profile.ts).
3. Botao de logout.

## Pontos de atencao
- Editar apelido revalida unicidade.
- Total de pontos sempre via query agregada server-side, nunca somado no client.
- time do coracao e um codigo de team do seed.

## Fora de escopo
Figurinhas, missoes, palpites especiais (backlog). Avatar upload (backlog).

## Must-haves
- [ ] Perfil exibe apelido, time do coracao e total de pontos corretos.
- [ ] Edicao de apelido salva e bloqueia duplicado.
- [ ] Edicao de time do coracao salva.

## Verificacao
Abrir perfil, editar apelido para um existente (deve falhar) e para um novo (deve salvar).

## Commit
feat(profile): perfil com edicao de apelido e time do coracao


## Output esperado (conferir no Passo 3 - VALIDAR)
Tela /perfil exibe apelido, time do coracao e total de pontos corretos. Edicao de apelido e time salvam; apelido duplicado bloqueia.

## Registro no backlog (Passo 1 e Passo 4)
- Passo 1: leia .planning/backlog.md inteiro. Marque esta task como EM ANDAMENTO na
  secao 2. Copie os must-haves acima para a secao 3. Escreva o plano na secao 5.
- Passo 4: marque a task como CONCLUIDA na secao 2, marque os must-haves na secao 3 com
  evidencia, adicione decisoes novas na secao 4, e registre a linha de log na secao 5
  com o commit. So entao a task esta fechada.
