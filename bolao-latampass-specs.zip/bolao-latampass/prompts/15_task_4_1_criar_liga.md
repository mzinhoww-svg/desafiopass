# Task 4.1 - Criar liga

Cole junto com 00_PROTOCOLO.md.

## Objetivo
Criar liga privada com nome, gerando token de convite unico. O dono entra como membro.
Respeitar o limite de 1 liga para usuario basico.

## Contexto a ler antes
- prompts/00_PROTOCOLO.md
- specs/DATA_SPEC.md secao 4 (token) e secao 5 (limite e edge cases de liga)
- wireframe tela 7 (Ligas)

## Escopo exato
1. app/ligas/page.tsx: abas liga publica (link para /ranking) e liga privada. Lista
   minhas ligas (criadas e entradas). Botoes criar liga e entrar no grupo.
2. app/actions/liga.ts Server Action criar liga:
   - validar createLeagueSchema,
   - checar limite: basico (is_premium false) so pode estar em 1 liga (owner + member).
     Se ja em 1, bloquear com mensagem clara,
   - gerar inviteToken (crypto, DATA_SPEC 4). Em colisao de unique, tentar de novo ate
     3 vezes,
   - inserir a liga e inserir o owner em league_members.
3. Exibir o link de convite da liga criada.

## Edge cases (DATA_SPEC secao 5)
- Basico ja em 1 liga tenta criar outra: bloqueado.
- Owner conta como membro (ocupa a vaga).
- Colisao de token: regenerar.

## Must-haves
- [ ] Criar liga gera link de convite e inscreve o dono.
- [ ] Limite de 1 liga para basico respeitado.
- [ ] Token unico e nao adivinhavel.

## Verificacao
Criar liga, ver o link, tentar criar uma segunda como basico (deve bloquear).

## Commit
feat(leagues): criar liga privada com token de convite e limite de basico


## Output esperado (conferir no Passo 3 - VALIDAR)
Criar liga gera link de convite e inscreve o dono. Limite de 1 liga para basico respeitado. Token unico e nao adivinhavel.

## Registro no backlog (Passo 1 e Passo 4)
- Passo 1: leia .planning/backlog.md inteiro. Marque esta task como EM ANDAMENTO na
  secao 2. Copie os must-haves acima para a secao 3. Escreva o plano na secao 5.
- Passo 4: marque a task como CONCLUIDA na secao 2, marque os must-haves na secao 3 com
  evidencia, adicione decisoes novas na secao 4, e registre a linha de log na secao 5
  com o commit. So entao a task esta fechada.
