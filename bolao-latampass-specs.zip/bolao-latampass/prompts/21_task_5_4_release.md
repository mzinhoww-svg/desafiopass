# Task 5.4 - Release

Cole junto com 00_PROTOCOLO.md.

## Objetivo
Merge na main, deploy de producao na Vercel e tag v1.0.0. Fluxo ponta a ponta funciona.

## Contexto a ler antes
- prompts/00_PROTOCOLO.md
- CLAUDE.md secao "Workflow de commit"
- ROADMAP.md (definicao de done do Milestone 1)

## Escopo exato
1. Garantir checks verdes no PR final.
2. Merge na main e deploy de producao na Vercel.
3. Conferir variaveis de ambiente de producao (Postgres, AUTH_SECRET).
4. Rodar o seed no banco de producao (se aplicavel ao ambiente).
5. Tag v1.0.0.

## Must-haves (definicao de done do Milestone 1)
- [ ] Producao no ar.
- [ ] Cadastro, login, palpite, pontuacao, ranking, criar e entrar em liga funcionam
      ponta a ponta.
- [ ] Admin insere resultado e dispara pontuacao.
- [ ] Identidade LATAM aplicada.
- [ ] Tag v1.0.0 criada.

## Verificacao
Executar o fluxo completo em producao com um usuario real de teste.

## Commit / tag
chore(release): v1.0.0 bolao latam pass copa 2026


## Output esperado (conferir no Passo 3 - VALIDAR)
Producao no ar na Vercel. Fluxo ponta a ponta funciona. Admin pontua. Tag v1.0.0 criada.

## Registro no backlog (Passo 1 e Passo 4)
- Passo 1: leia .planning/backlog.md inteiro. Marque esta task como EM ANDAMENTO na
  secao 2. Copie os must-haves acima para a secao 3. Escreva o plano na secao 5.
- Passo 4: marque a task como CONCLUIDA na secao 2, marque os must-haves na secao 3 com
  evidencia, adicione decisoes novas na secao 4, e registre a linha de log na secao 5
  com o commit. So entao a task esta fechada.
