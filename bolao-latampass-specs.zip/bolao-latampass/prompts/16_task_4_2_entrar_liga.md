# Task 4.2 - Entrar na liga

Cole junto com 00_PROTOCOLO.md.

## Objetivo
Entrar em liga privada pelo link de convite, validando o token e o limite.

## Contexto a ler antes
- prompts/00_PROTOCOLO.md
- specs/DATA_SPEC.md secao 5 (edge cases de liga)
- wireframe tela 9 (Convite)

## Escopo exato
1. app/ligas/entrar/[token]/page.tsx: valida o token. Se valido, mostra a liga e botao
   entrar. Se invalido, mostra erro "convite invalido".
2. Server Action entrar na liga em liga.ts:
   - validar token existente,
   - checar limite do usuario (basico: 1 liga),
   - inserir em league_members. PK (league_id, user_id) impede entrada dupla.

## Edge cases (DATA_SPEC secao 5)
- Entrar duas vezes na mesma liga: bloqueado pela PK, mensagem "voce ja esta nesta liga".
- Token invalido ou inexistente: pagina de erro.
- Basico que ja tem 1 liga: bloqueado.

## Must-haves
- [ ] Abrir o link valido inscreve o usuario logado.
- [ ] Token invalido mostra erro.
- [ ] Entrada dupla bloqueada.
- [ ] Limite de basico respeitado.

## Verificacao
Entrar por um link valido, tentar de novo (deve bloquear), abrir um token invalido.

## Commit
feat(leagues): entrar em liga por convite com validacao de token e limite


## Output esperado (conferir no Passo 3 - VALIDAR)
Abrir link valido inscreve o usuario; token invalido mostra erro; entrada dupla bloqueada; limite de basico respeitado.

## Registro no backlog (Passo 1 e Passo 4)
- Passo 1: leia .planning/backlog.md inteiro. Marque esta task como EM ANDAMENTO na
  secao 2. Copie os must-haves acima para a secao 3. Escreva o plano na secao 5.
- Passo 4: marque a task como CONCLUIDA na secao 2, marque os must-haves na secao 3 com
  evidencia, adicione decisoes novas na secao 4, e registre a linha de log na secao 5
  com o commit. So entao a task esta fechada.
