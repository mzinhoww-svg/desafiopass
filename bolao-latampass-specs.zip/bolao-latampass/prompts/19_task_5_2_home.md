# Task 5.2 - Home

Cole junto com 00_PROTOCOLO.md.

## Objetivo
Home com destaque do bolao, proximos jogos do mata-mata e CTA para palpitar.

## Contexto a ler antes
- prompts/00_PROTOCOLO.md
- wireframe tela 1 (Home)
- BRANDING.md (hero, header, CTA)

## Escopo exato
1. app/page.tsx: hero com a identidade LATAM, CTA "Palpitar agora" para /partidas, e
   uma lista curta dos proximos jogos (carregados do banco, ordenados por kickoff,
   apenas os futuros), com selo de fase e selo Brasil.
2. Navegacao principal (tab bar ou header) para Partidas, Ranking, Ligas, Perfil.

## Pontos de atencao
- Proximos jogos = futuros por kickoff, status agendada.
- Horario em Brasilia.

## Must-haves
- [ ] Home com identidade LATAM e CTA para palpitar.
- [ ] Proximos jogos do mata-mata listados.
- [ ] Navegacao para as telas principais.

## Verificacao
Abrir a home, conferir hero, CTA e proximos jogos.

## Commit
feat(home): home com hero, proximos jogos e navegacao principal


## Output esperado (conferir no Passo 3 - VALIDAR)
Home com hero LATAM, CTA Palpitar agora, proximos jogos do mata-mata e navegacao principal.

## Registro no backlog (Passo 1 e Passo 4)
- Passo 1: leia .planning/backlog.md inteiro. Marque esta task como EM ANDAMENTO na
  secao 2. Copie os must-haves acima para a secao 3. Escreva o plano na secao 5.
- Passo 4: marque a task como CONCLUIDA na secao 2, marque os must-haves na secao 3 com
  evidencia, adicione decisoes novas na secao 4, e registre a linha de log na secao 5
  com o commit. So entao a task esta fechada.
