# Task 5.1 - Regras e premios

Cole junto com 00_PROTOCOLO.md.

## Objetivo
Tela /regras espelhando as regras de pontuacao, prazos e a tabela de premios em milhas
LATAM Pass.

## Contexto a ler antes
- prompts/00_PROTOCOLO.md
- REQUISITOS.md secoes 3, 4, 9 (palpites, pontuacao, premiacao)
- specs/SCORING_SPEC.md (tabelas de pontos e multiplicadores)
- wireframe tela 11 (Regras e premios)

## Escopo exato
1. app/regras/page.tsx: conteudo de regras (como participar, prazos, pontuacao,
   multiplicadores) e a tabela de premios POR POSICAO EM MILHAS LATAM PASS.
2. Os valores de milhas ficam como "a definir" ate o time fechar, mas a estrutura de
   faixas (1, 2-3, 4-10, 11-100) deve estar pronta.

## Proibicoes
- Premio nunca em reais ou cartao. Sempre milhas LATAM Pass.
- Sem emoji. Tom PROF.

## Must-haves
- [ ] Regras completas espelham REQUISITOS e SCORING_SPEC.
- [ ] Tabela de premios em milhas, com as faixas de posicao.

## Verificacao
Abrir /regras, conferir pontuacao, multiplicadores e premio em milhas.

## Commit
feat(rules): tela de regras e premios em milhas latam pass


## Output esperado (conferir no Passo 3 - VALIDAR)
Tela /regras com regras espelhando REQUISITOS e SCORING_SPEC, e tabela de premios em milhas LATAM Pass com as faixas de posicao.

## Registro no backlog (Passo 1 e Passo 4)
- Passo 1: leia .planning/backlog.md inteiro. Marque esta task como EM ANDAMENTO na
  secao 2. Copie os must-haves acima para a secao 3. Escreva o plano na secao 5.
- Passo 4: marque a task como CONCLUIDA na secao 2, marque os must-haves na secao 3 com
  evidencia, adicione decisoes novas na secao 4, e registre a linha de log na secao 5
  com o commit. So entao a task esta fechada.
