# prompts/INDEX.md

Biblioteca de prompts do Bolao LATAM Pass. Um arquivo por task. Cada prompt e
autocontido: diz o que ler, o escopo, o que e proibido, os must-haves, a verificacao, o
OUTPUT ESPERADO e como REGISTRAR NO BACKLOG.

## Como usar no Claude Code

Para cada task, na ordem abaixo:

1. Cole `00_PROTOCOLO.md` (sempre, em toda task). Ele define o CICLO: ler backlog,
   planejar, marcar em andamento, executar marcando sub-itens, validar contra o output
   esperado, gravar no backlog, commitar, entregar, parar.
2. Cole o arquivo da task.
3. O Claude Code le o .planning/backlog.md, devolve o PLANO, e so coda apos isso. Em
   ambiguidade, ele registra no backlog e pergunta.
4. Ao fim, ele roda a VALIDACAO contra o output esperado, GRAVA no backlog (status,
   must-haves, decisoes, log) e faz o COMMIT atomico.
5. So entao avance. Uma task por prompt. Contexto fresco por task.

O backlog (.planning/backlog.md) e a memoria viva. Toda task le no inicio e grava no
fim. Sem isso, perde estado e alucina.

## Etapa de design (antes do desenvolvimento)

| Ordem | Arquivo | Etapa | Saida |
|---|---|---|---|
| 0b | 00b_wireframe_refinado.md | Wireframe refinado para aprovacao | wireframes-refinado.html |

A etapa 0b aplica a sequencia de skills (impeccable para rigor, tripled-ui para padroes
e assets, ui-ux-pro-max para estetica) e produz o preview visual. Aprovar antes de
codar. O arquivo wireframes-refinado.html (ja incluso no pacote) e a referencia visual
oficial das telas.

## Ordem de execucao do desenvolvimento

| Ordem | Arquivo | Task | Depende de |
|---|---|---|---|
| 1 | 01_task_0_1_scaffold.md | Scaffold | - |
| 2 | 02_task_0_2_branding.md | Sistema de design refinado | 0.1 |
| 3 | 03_task_0_3_banco.md | Banco e schema | 0.1 |
| 4 | 04_task_0_4_seed.md | Seed Copa 2026 | 0.3 |
| 5 | 05_task_0_5_deploy.md | Deploy e CI | 0.1 |
| 6 | 06_task_1_1_auth.md | NextAuth | 0.3 |
| 7 | 07_task_1_2_cadastro.md | Cadastro | 1.1 |
| 8 | 08_task_1_3_perfil.md | Perfil | 1.1 |
| 9 | 09_task_2_1_scoring.md | Pontuacao (critico) | - (puro) |
| 10 | 10_task_2_2_lista_partidas.md | Lista de partidas | 0.4, 2.1 |
| 11 | 11_task_2_3_palpite.md | Registrar palpite | 2.2 |
| 12 | 12_task_2_4_admin_pontuar.md | Admin pontua | 2.1, 2.3 |
| 13 | 13_task_2_5_resultado_ui.md | Resultado na UI | 2.4 |
| 14 | 14_task_3_1_ranking.md | Ranking geral (sensivel) | 2.4 |
| 15 | 15_task_4_1_criar_liga.md | Criar liga | 3.1 |
| 16 | 16_task_4_2_entrar_liga.md | Entrar na liga | 4.1 |
| 17 | 17_task_4_3_ranking_liga.md | Ranking da liga | 4.2, 3.1 |
| 18 | 18_task_5_1_regras.md | Regras e premios | 2.1 |
| 19 | 19_task_5_2_home.md | Home | 2.2 |
| 20 | 20_task_5_3_qa.md | QA e responsivo | tudo |
| 21 | 21_task_5_4_release.md | Release | tudo |

## Tasks que exigem rigor maximo

- 09 (scoring) e 14 (ranking): zonas onde alucinacao custa caro. Leia specs/SCORING_SPEC
  e specs/RANKING_SPEC inteiras. Contrato literal, tabela de verdade, casos de teste.
- 0.2 e as tasks de UI: seguem specs/DESIGN_SPEC.md e a sequencia de skills. Rodar o
  checklist anti-slop (DESIGN_SPEC secao 7) antes de aprovar qualquer tela.

## Mapa de documentos de referencia

- Regras de negocio: REQUISITOS.md
- Arquitetura e pastas: ESTRUTURA.md
- Marca base: BRANDING.md
- Design refinado (3 skills): specs/DESIGN_SPEC.md
- Pontuacao (contrato literal): specs/SCORING_SPEC.md
- Ranking (contrato literal e edge cases): specs/RANKING_SPEC.md
- Schema, prazo, timezone, ligas: specs/DATA_SPEC.md
- Comportamento do agente e ciclo: prompts/00_PROTOCOLO.md
- Memoria viva e progresso: .planning/backlog.md
- Plano de fases: ROADMAP.md
- Referencia visual: wireframes-refinado.html
