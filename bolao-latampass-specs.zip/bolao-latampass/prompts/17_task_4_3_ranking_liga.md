# Task 4.3 - Ranking da liga

Cole junto com 00_PROTOCOLO.md.

## Objetivo
Tela da liga com ranking interno apenas dos membros, usando a mesma logica de
ordenacao e desempate do ranking geral.

## Contexto a ler antes
- prompts/00_PROTOCOLO.md
- specs/RANKING_SPEC.md secao 8.5 (SQL de liga) e secoes 3 e 4 (desempate, competition)
- wireframe tela 8 (Ranking da liga)

## Escopo exato
1. lib/queries/ranking.ts: getLeagueRanking (assinatura da RANKING_SPEC secao 7),
   reaproveitando a mesma logica de posicao e desempate, com a CTE partindo de
   league_members (secao 8.5).
2. app/ligas/[id]/page.tsx: ranking interno dos membros, link de convite copiavel,
   realce do usuario logado. So membros enxergam (ou ao menos o ranking lista so membros).

## Pontos de atencao
- Mesma logica de competition ranking e desempate do geral. Nao duplicar regra
  divergente.
- Mesma pontuacao acumulada (predictions.points) usada no geral.

## Must-haves
- [ ] Liga mostra ranking so dos membros, ordenado com competition ranking.
- [ ] Desempate identico ao geral.
- [ ] /ligas lista minhas ligas (criadas e entradas).

## Verificacao
Liga com 3-4 membros semeados, conferir ordem e posicoes. Confirmar que so membros
aparecem.

## Commit
feat(leagues): ranking interno da liga reaproveitando a logica do ranking geral


## Output esperado (conferir no Passo 3 - VALIDAR)
Tela /ligas/[id] mostra ranking so dos membros com a mesma logica de competition ranking e desempate do geral. /ligas lista minhas ligas.

## Registro no backlog (Passo 1 e Passo 4)
- Passo 1: leia .planning/backlog.md inteiro. Marque esta task como EM ANDAMENTO na
  secao 2. Copie os must-haves acima para a secao 3. Escreva o plano na secao 5.
- Passo 4: marque a task como CONCLUIDA na secao 2, marque os must-haves na secao 3 com
  evidencia, adicione decisoes novas na secao 4, e registre a linha de log na secao 5
  com o commit. So entao a task esta fechada.
