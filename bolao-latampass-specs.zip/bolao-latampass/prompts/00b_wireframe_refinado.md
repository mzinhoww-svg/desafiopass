# Etapa 0b - Wireframe refinado (preview antes do desenvolvimento total)

Cole junto com 00_PROTOCOLO.md. Esta etapa vem ANTES da Task 0.1. Produz um preview
visual navegavel para aprovacao, aplicando o design refinado, sem ainda construir o
app real. Nao escreve codigo de producao; entrega um HTML de validacao.

## Objetivo
Gerar um wireframe de alta fidelidade das 12 telas do MVP com o sistema de design
refinado (DESIGN_SPEC), para o time aprovar a direcao visual antes do desenvolvimento.

## Sequencia de skills (ordem obrigatoria)
1. impeccable: aplicar o rigor e o checklist anti-slop (DESIGN_SPEC secao 7).
2. tripled-ui: padroes de layout, Lucide para icones, hierarquia visual de producao.
3. ui-ux-pro-max: estetica atletica e tokens de rank ouro/prata/bronze.

## Contexto a ler antes
- prompts/00_PROTOCOLO.md
- specs/DESIGN_SPEC.md (direcao visual completa)
- BRANDING.md (marca base)
- REQUISITOS.md secao 11 (lista de telas) e as specs de SCORING e RANKING para os dados
  exibidos (selos, pontos, posicoes)

## Escopo exato
1. Um unico arquivo wireframes-refinado.html, navegavel, com as 12 telas do MVP em alta
   fidelidade visual, aplicando tokens, tipografia atletica, selos, badges de rank
   ouro/prata/bronze, e estados (sem palpite, palpitado, encerrado, prazo, vazio).
2. As telas: Home, Cadastro, Partidas, Palpite, Palpite encerrado, Ranking geral, Ligas
   lista, Ranking da liga, Convite, Perfil, Regras e premios, Admin resultado.
3. Marca aplicada de verdade: header navy com gradiente, score-input oversized, ranking
   como lista densa com badges de podio, premio em milhas.
4. Anotacao curta em cada tela com a rota e o estado representado.

## Banimentos (conferir antes de entregar)
Mesmos do impeccable: sem side-stripe, sem gradient text, sem glassmorphism decorativo,
sem eyebrow em toda secao, sem grid de cards identicos, sem fundo cream. Sem emoji
estrutural (usar Lucide ou descricao). Contraste adequado.

## Fora de escopo
Codigo de producao, banco, logica. Isso comeca na Task 0.1 apos a aprovacao.

## Must-haves
- [ ] 12 telas em alta fidelidade com o design refinado.
- [ ] Tokens, tipografia atletica e badges de rank ouro/prata/bronze aplicados.
- [ ] Estados representados (sem palpite, palpitado, encerrado, prazo, vazio).
- [ ] Checklist anti-slop do DESIGN_SPEC secao 7 aprovado.
- [ ] Premio em milhas, sem reais.

## Verificacao
Abrir o HTML, navegar pelas 12 telas, rodar o checklist anti-slop. Aprovar a direcao
com o time antes de seguir para a Task 0.1.

## Commit
design(preview): wireframe refinado das 12 telas para aprovacao

## Output esperado (conferir no Passo 3 - VALIDAR)
Arquivo wireframes-refinado.html navegavel, 12 telas, identidade LATAM Pass refinada,
checklist anti-slop aprovado. Serve de referencia visual para as tasks de UI.

## Registro no backlog (Passo 1 e Passo 4)
- Passo 1: leia .planning/backlog.md inteiro. Adicione esta etapa 0b na secao 2 como
  EM ANDAMENTO. Copie os must-haves para a secao 3. Escreva o plano na secao 5.
- Passo 4: marque 0b como CONCLUIDA, marque os must-haves com evidencia, e registre na
  secao 5 com o commit. Anote na secao 4 que o wireframe-refinado e a referencia visual
  oficial das telas.
