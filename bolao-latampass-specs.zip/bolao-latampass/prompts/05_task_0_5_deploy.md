# Task 0.5 - Deploy e CI

Cole junto com 00_PROTOCOLO.md.

## Objetivo
Conectar o repo a Vercel com preview por PR e configurar GitHub Actions rodando lint,
typecheck e test.

## Contexto a ler antes
- prompts/00_PROTOCOLO.md
- CLAUDE.md secao "Workflow de commit" e "Comandos"
- ESTRUTURA.md secao "Stack" (linha de CI)

## Escopo exato
1. Conectar o projeto a Vercel (instrucoes para o usuario, mais qualquer config de
   projeto necessaria, ex vercel.json se preciso).
2. Variaveis de ambiente da Vercel documentadas (Postgres e AUTH_SECRET).
3. .github/workflows/ci.yml: roda em pull_request. Passos: instalar deps, lint,
   typecheck, test. Falha vermelha bloqueia.
4. Garantir que npm run build passa, pois a Vercel usa build de producao.

## Fora de escopo
Deploy de producao final (Task 5.4). Qualquer feature.

## Must-haves
- [ ] Push em branch gera preview deploy na Vercel.
- [ ] PR dispara o workflow com lint, typecheck e test.
- [ ] npm run build passa localmente.

## Verificacao
Abrir um PR de teste, confirmar o preview e os checks verdes.

## Commit
ci(setup): github actions e preview deploy vercel


## Output esperado (conferir no Passo 3 - VALIDAR)
PR de teste gera preview deploy verde na Vercel. Workflow ci.yml roda lint, typecheck e test e bloqueia em vermelho. `npm run build` passa local.

## Registro no backlog (Passo 1 e Passo 4)
- Passo 1: leia .planning/backlog.md inteiro. Marque esta task como EM ANDAMENTO na
  secao 2. Copie os must-haves acima para a secao 3. Escreva o plano na secao 5.
- Passo 4: marque a task como CONCLUIDA na secao 2, marque os must-haves na secao 3 com
  evidencia, adicione decisoes novas na secao 4, e registre a linha de log na secao 5
  com o commit. So entao a task esta fechada.
