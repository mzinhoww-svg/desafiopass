# Task 0.1 - Scaffold do projeto

Cole junto com 00_PROTOCOLO.md.

## Objetivo
Criar o projeto Next.js 15 com TypeScript estrito, Tailwind v4, scripts de package.json
e repositorio Git inicial. Nada de feature ainda. So a base roda.

## Contexto a ler antes
- prompts/00_PROTOCOLO.md
- ESTRUTURA.md secao "Organizacao de pastas" e "Stack"
- CLAUDE.md secao "Comandos"

## Escopo exato (so isto)
1. Inicializar Next.js 15 com App Router e TypeScript. Confirmar na doc oficial a
   sintaxe atual de create-next-app e a estrutura do App Router da versao 15.
2. Configurar TypeScript estrito em tsconfig (strict true, noUncheckedIndexedAccess true).
3. Tailwind CSS v4 instalado e funcionando (confirmar setup v4, que difere do v3).
4. package.json com os scripts: dev, build, start, lint, typecheck (tsc --noEmit),
   test (vitest), db:generate, db:migrate, db:seed, db:studio. Os scripts de db podem
   apontar para arquivos ainda inexistentes; serao criados na Task 0.3 e 0.4. Deixe-os
   declarados mas e aceitavel que falhem ate la.
5. Criar a arvore de pastas vazia conforme ESTRUTURA.md (app/, lib/, components/,
   drizzle/, etc) com .gitkeep onde necessario.
6. app/layout.tsx minimo e app/page.tsx com um placeholder textual simples e um header
   navy provisorio (sera estilizado na Task 0.2).
7. .gitignore adequado (node_modules, .env*, .next, etc).
8. git init, primeiro commit, e instrucao de como conectar ao GitHub remoto.

## Fora de escopo
Tokens de marca completos (Task 0.2). Banco (0.3). Seed (0.4). Qualquer rota de feature.

## Must-haves (verificar um a um)
- [ ] npm run dev sobe sem erro e a home renderiza um header navy provisorio.
- [ ] npm run typecheck roda sem erro de configuracao.
- [ ] Estrutura de pastas de ESTRUTURA.md existe.
- [ ] Repositorio Git inicializado com primeiro commit.

## Verificacao
Rodar npm run dev e abrir localhost:3000. Rodar npm run typecheck. Listar a arvore.

## Commit
chore(setup): scaffold next 15, typescript estrito e tailwind v4


## Output esperado (conferir no Passo 3 - VALIDAR)
Projeto Next 15 rodando: `npm run dev` abre localhost:3000 com header navy provisorio. `npm run typecheck` limpo. Arvore de pastas de ESTRUTURA.md criada. Repo git com 1o commit.

## Registro no backlog (Passo 1 e Passo 4)
- Passo 1: leia .planning/backlog.md inteiro. Marque esta task como EM ANDAMENTO na
  secao 2. Copie os must-haves acima para a secao 3. Escreva o plano na secao 5.
- Passo 4: marque a task como CONCLUIDA na secao 2, marque os must-haves na secao 3 com
  evidencia, adicione decisoes novas na secao 4, e registre a linha de log na secao 5
  com o commit. So entao a task esta fechada.
