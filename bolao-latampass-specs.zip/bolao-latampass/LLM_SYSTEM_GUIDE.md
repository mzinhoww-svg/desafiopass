# LATAM Pass · Elevate Design System — Guia de Geração para LLM

> Documento operacional. Objetivo: permitir que um modelo de linguagem gere novos
> slides **no padrão Elevate** sem ambiguidade. Siga as regras na ordem apresentada.
> Os arquivos de referência são `LATAM Pass Elevate Design.html`, `brand.css` e a
> pasta `assets/`.
>
> NOTA PARA ESTE PROJETO (Bolao LATAM Pass): este guia descreve um sistema de SLIDES.
> O Bolao e um APP mobile. A traducao das regras de marca deste guia para componentes
> de app esta em specs/DESIGN_SPEC.md. Use este guia como fonte de cor, fonte e
> disciplina visual; use o DESIGN_SPEC para os componentes de tela (header, match-card,
> score-input, ranking-row).

---

## 0. Como produzir um slide (resumo de 6 passos)

1. **Crie um `<section class="slide slide--XXX">`** dentro de `<deck-stage>`, com `data-screen-label="NN Rótulo"`.
2. **Escolha o frame** (claro vs. escuro) pela tabela da §3.
3. **Abra um `<div class="frame">`** e comece SEMPRE por `.kicker` → `.h-title` (uma ideia só).
4. **Escolha 1 componente de corpo** (KPI, cards, tabela, barras, fluxo ou quote). Nunca misture mais de 2.
5. **Aplique no máximo 1 acento** (`.accent`) e use o itálico-assinatura (`.elevate`) apenas em capa/seção/quote/encerramento.
6. **Feche com o rodapé** `.deck-foot` (logo + nº da página).

---

## 2. Tokens de marca (valores exatos)

| Token | Hex | Uso |
|---|---|---|
| Índigo | `#16064F` | base escura, texto-tinta, cor primária |
| Índigo claro | `#2C1183` | parceiro de gradiente |
| Índigo profundo | `#0C0233` | fundo `--ink`, vinheta |
| Rosa | `#FE3173` | **acento 1** (em fundo claro) |
| Roxo | `#9E4CFE` | acento 2 / gradientes |
| Lima | `#C2F24A` | positivo / destaque |
| Teal | `#0AE7C6` | **acento em fundo escuro** / dados |
| Cloud | `#F3F2F8` | fundo de slide claro |
| Paper | `#FFFFFF` | cards, tabelas |
| Ink | `#18112E` | texto em fundo claro |
| Muted | `#6B6586` | texto secundário (claro) |
| Muted-dark | `#B9B2D6` | texto secundário (escuro) |

**Regra de cor 60·30·10:** 60% neutro (cloud/paper), 30% índigo, 10% acento vibrante.
Um único elemento de acento por slide. O acento muda conforme o fundo:
**rosa em fundo claro, teal em fundo escuro.**

---

## 3. Frames de slide (escolha do fundo)

| Classe | Aparência | Usar em |
|---|---|---|
| `slide--light` | Cloud (#F3F2F8) | conteúdo geral, análise, listas |
| `slide--paper` | Branco puro | tabelas, tipografia, grids densos |
| `slide--dark` | Índigo c/ gradiente | capa, divisor de seção, dados de impacto, encerramento |
| `slide--ink` | Índigo profundo chapado | quotes, momentos-herói |

Heurística: **claro = ler e analisar; escuro = sentir e impactar.**

---

## 5. Escala tipográfica (Plus Jakarta Sans)

| Classe | Tamanho | Peso | Uso |
|---|---|---|---|
| `.h-display` | 112px | 800 | título de capa |
| `.h-hero` | 96px | 800 | herói / encerramento |
| `.h-section` | 88px | 800 | divisor de seção |
| `.h-title` | 68px | 800 | **título de slide (padrão)** |
| `.h-sub` | 34px | 500 | subtítulo (muted) |
| `.lead` | 30px | 500 | parágrafo de abertura |
| `.body` | 26px | 400 | texto de apoio (muted) |
| `.kicker` | 24px | 700 | rótulo (caixa-alta, com traço) |

- Itálico-assinatura: envolva 1–2 palavras em `<span class="elevate accent">…</span>`.
  Use só em capa, divisor, quote e encerramento — nunca em títulos de conteúdo.

---

## 9. Proibições (não faça)

- Mais de um acento por slide / parede inteira em rosa ou teal.
- Itálico `.elevate` em título de conteúdo, tabela ou corpo.
- Texto < 20px; conteúdo encostando nas bordas.
- Gradientes aleatórios, sombras pesadas, emojis decorativos, ícones inventados em excesso.
- Dois fundos escuros seguidos sem conteúdo claro entre eles.
- Misturar 3+ componentes de dado no mesmo slide.
- Reescrever `brand.css`; criar cores fora da paleta.

---

> Versao completa do guia (todas as secoes, incluindo componentes de slide KPI/cards/
> tabela/barras/fluxo/quote/pills/asa) fornecida pelo usuario. Para o app, a referencia
> operacional e specs/DESIGN_SPEC.md, que traduz estas regras em componentes mobile.
