# .planning/backlog.md

LOG VIVO DE EXECUCAO. Este arquivo e a memoria persistente do projeto. Toda task le
este arquivo no inicio e grava nele no fim. E a defesa principal contra alucinacao e
perda de estado entre sessoes de contexto fresco.

REGRA: nenhuma task comeca sem ler este arquivo inteiro. Nenhuma task termina sem
atualizar a secao 2 (estado das tasks) e a secao 4 (decisoes e descobertas). Se este
arquivo divergir do codigo real, PARE e reconcilie antes de prosseguir.

---

## 1. Como atualizar este log (protocolo)

Cada task segue o ciclo de cinco passos. Em cada passo, grave aqui:

1. PLANEJAR: ao iniciar, mova a task para "EM ANDAMENTO" na secao 2 e cole o plano de
   1 a 3 linhas em "log cronologico" (secao 5).
2. EXECUTAR: conforme implementa, marque os sub-itens da task como [x] na secao 3.
3. VALIDAR: ao terminar, registre o resultado da verificacao de cada must-have na
   secao 3 (passou / como).
4. GRAVAR: mova a task para "CONCLUIDA" na secao 2, registre o hash/mensagem do commit
   na secao 5, e adicione qualquer decisao ou descoberta na secao 4.
5. ENTREGAR: so entao a task esta fechada. A proxima task le este arquivo atualizado.

Formato de status na secao 2: PENDENTE, EM ANDAMENTO, CONCLUIDA, BLOQUEADA.
Se BLOQUEADA, escrever o motivo e a pergunta aberta na secao 6.

---

## 2. Estado das tasks (fonte da verdade do progresso)

Atualizar o status a cada transicao.

### Slice 0 - Fundacao
- [ ] 0.1 Scaffold .................................. PENDENTE
- [ ] 0.2 Tokens de marca + design refinado ......... PENDENTE
- [ ] 0.3 Banco e schema ............................ PENDENTE
- [ ] 0.4 Seed Copa 2026 ............................ PENDENTE
- [ ] 0.5 Deploy e CI ............................... PENDENTE

### Slice 1 - Auth e perfil
- [ ] 1.1 NextAuth Credentials ...................... PENDENTE
- [ ] 1.2 Cadastro .................................. PENDENTE
- [ ] 1.3 Perfil .................................... PENDENTE

### Slice 2 - Palpites e pontuacao
- [ ] 2.1 Logica de pontuacao (critico) ............. PENDENTE
- [ ] 2.2 Lista de partidas ......................... PENDENTE
- [ ] 2.3 Registrar palpite ......................... PENDENTE
- [ ] 2.4 Admin encerra e pontua .................... PENDENTE
- [ ] 2.5 Resultado na UI ........................... PENDENTE

### Slice 3 - Ranking
- [ ] 3.1 Ranking geral (sensivel) .................. PENDENTE

### Slice 4 - Ligas privadas
- [ ] 4.1 Criar liga ................................ PENDENTE
- [ ] 4.2 Entrar na liga ............................ PENDENTE
- [ ] 4.3 Ranking da liga ........................... PENDENTE

### Slice 5 - Regras e acabamento
- [ ] 5.1 Regras e premios .......................... PENDENTE
- [ ] 5.2 Home ...................................... PENDENTE
- [ ] 5.3 QA e responsivo ........................... PENDENTE
- [ ] 5.4 Release ................................... PENDENTE

---

## 3. Checklist detalhado por task (must-haves)

Marcar cada sub-item [x] ao satisfazer, com uma palavra de evidencia. Copiar os
must-haves do prompt da task correspondente ao iniciar. Exemplo de padrao (Task 0.1):

### 0.1 Scaffold
- [ ] npm run dev sobe home com header navy provisorio  ->
- [ ] npm run typecheck sem erro                         ->
- [ ] estrutura de pastas de ESTRUTURA.md existe         ->
- [ ] git init e primeiro commit                         ->

(As demais tasks copiam seus must-haves do respectivo prompt em prompts/ quando
iniciadas. Preencher ao executar, nao antes.)

---

## 4. Decisoes travadas e descobertas (apendice cronologico)

Registrar aqui toda decisao tomada e toda descoberta que afete tasks futuras.

Decisoes ja travadas antes do inicio do desenvolvimento:
- D1. Stack: Next.js 15 App Router, TypeScript estrito, Vercel Postgres, Drizzle,
  NextAuth v5, Tailwind v4. Deploy Vercel, repo GitHub, CI GitHub Actions.
- D2. MVP: palpites + pontuacao + ranking geral + ligas privadas. Jogos via seed
  estatico. Sem API externa de futebol.
- D3. Pontuacao isolada em lib/scoring.ts, pura, testada antes da UI. Regra unica.
  Contrato em specs/SCORING_SPEC.md.
- D4. Ranking: competition ranking, desempate deterministico (pontos, placares exatos,
  created_at, user_id). pontos zero exibe travessao. Contrato em specs/RANKING_SPEC.md.
- D5. Schema grava coluna criterion em predictions, junto com points, para exact_count
  do ranking sem recomputo. Contrato em specs/DATA_SPEC.md.
- D6. Prazo: trava no kickoff (now === kickoff recusa). UTC no banco, Brasilia so na
  exibicao.
- D7. [SUPERADA por D12] Design: Trebuchet MS mantida (institucional), com estetica atletica via peso,
  escala e tracking. Estrategia committed (navy domina, magenta acentua). Tokens de
  rank ouro/prata/bronze. Lucide para icones, Framer Motion para motion. Banimentos do
  impeccable. Contrato em specs/DESIGN_SPEC.md.
- D8. Premio sempre em milhas LATAM Pass, valores a definir pelo time.
- D9. Limite de liga: basico 1, socio 100 (V2). No MVP todos basico, limite efetivo 1.
- D10. O modulo de pontuacao foi pre-implementado e validado em reference-code/lib/
  (scoring.ts e scoring.test.ts), cobrindo os 27 casos da SCORING_SPEC (49 asseroes
  verdes). A Task 2.1 consiste em integrar esse codigo ao projeto e rodar a suite via
  vitest, nao em reescrever a regra do zero.

(Adicionar D10, D11, ... conforme surgirem durante o desenvolvimento.)

---

- D12: Identidade visual do app migrada para o LATAM Pass Elevate Design System
  (LLM_SYSTEM_GUIDE.md). Paleta Elevate oficial (indigo #16064F, rosa #FE3173, teal
  #0AE7C6, lima #C2F24A, roxo #9E4CFE), regra 60.30.10, acento por fundo (rosa em
  claro, teal em escuro). Fonte: Plus Jakarta Sans (substitui Trebuchet MS, decisao
  do usuario). DESIGN_SPEC reescrito traduzindo o sistema de SLIDES Elevate para o
  app mobile (nao porta componentes de slide). Tokens prontos em
  reference-code/styles/tokens.css. BRANDING.md rebaixado a referencia; DESIGN_SPEC
  manda. Guia .md e a unica fonte (arquivos html/css/js do Elevate nao usados).

## 5. Log cronologico (uma linha por evento)

Formato: [data] [task] acao | resultado | commit. Append-only.

- [pre-dev] reference-code/lib/scoring.ts e scoring.test.ts criados e validados (49 asseroes verdes) | pronto para integrar na Task 2.1

---

## 6. Bloqueios e perguntas abertas

Registrar ambiguidades que exigiram parar e perguntar. Quando respondida, mover a
resposta para a secao 4 e remover daqui.

- (nenhum no momento)

---

## 7. Fora do MVP (nao implementar sem virar Slice no ROADMAP)

- Palpites especiais: campeao e artilheiro (+150 cada), trava no 1o jogo.
- Ranking exclusivo socio LATAM Pass (equivalente ao Ranking Clube iFood).
- Rankings independentes por recorte: Copa completa, mata-mata, quartas.
- Estatistica da comunidade (percentual por resultado de partida).
- API externa de futebol (placares e chaveamento automaticos).
- Avanco dinamico do chaveamento mata-mata.
- Credito automatico de milhas e integracao com base de socios.
- Gestao de liga: sair, remover membro, renomear, transferir dono.
- Elevar limite de ligas para 100 (socio).
- Login social, recuperacao de senha por email.
- Fonte display condensada dedicada ao bolao (se o time aprovar formalmente).
- Chaveamento real completo da Copa 2026 (ge.globo.com) integrado ao seed: 16
  trinta-e-dois-avos com datas/horarios reais (UTC), 8 oitavas, 4 quartas, 2 semis,
  terceiro e final, com mapa de avanco. Bandeiras trocadas de emoji para 32 SVGs
  reais. Componente Flag criado. Specs (DATA, DESIGN, ESTRUTURA) e prompt 0.4
  atualizados. Varredura confirma zero emoji no pacote.
- Identidade migrada para Elevate Design System: DESIGN_SPEC e prompt 0.2 reescritos,
  tokens.css criado, BRANDING/CLAUDE/ESTRUTURA/README/ROADMAP/START_HERE/PROTOCOLO
  atualizados de navy+Trebuchet para indigo+Jakarta Elevate. Guia copiado ao pacote.
- Wireframe (wireframes-refinado.html) regenerado na identidade Elevate: paleta
  indigo/rosa/teal/lima, Plus Jakarta Sans, faixa 'minha posicao' em superficie escura
  com acento teal, legenda atualizada. Wireframe antigo (navy) removido do pacote.
