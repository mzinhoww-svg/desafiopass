# ESTRUTURA.md

Arquitetura tecnica, modelo de dados e organizacao de codigo do Bolao LATAM Pass.

---

## Stack e razao de escolha

| Camada | Escolha | Razao |
|---|---|---|
| Framework | Next.js 15 App Router | Server Components, Server Actions, deploy nativo Vercel |
| Linguagem | TypeScript estrito | Seguranca de tipos na logica de pontuacao |
| Banco | Vercel Postgres | Serverless, integrado a Vercel, sem ops |
| ORM | Drizzle | Schema type-safe, migracoes versionadas, leve |
| Auth | NextAuth v5 (Auth.js) | Credentials provider, sessao via JWT |
| Estilo | Tailwind CSS v4 | Tokens LATAM injetados, mobile first |
| Hospedagem | Vercel | Preview por PR, edge, zero config |
| CI | GitHub Actions + Vercel | Lint, typecheck, test no PR |

---

## Organizacao de pastas

```
bolao-latampass/
  CLAUDE.md
  REQUISITOS.md
  ESTRUTURA.md
  BRANDING.md
  ROADMAP.md
  README.md
  .env.example
  .planning/
    backlog.md
  drizzle/
    schema.ts            # tabelas Drizzle
    migrations/          # geradas por db:generate
  lib/
    scoring.ts           # logica pura de pontuacao. Testada.
    scoring.test.ts      # vitest dos exemplos de REQUISITOS secao 4
    db.ts                # client Drizzle + Vercel Postgres
    auth.ts              # config NextAuth v5
    validations.ts       # schemas Zod
    data/
      copa2026.ts        # seed estatico: selecoes e jogos do mata-mata
    utils/
      dates.ts           # UTC <-> horario de Brasilia, prazo de palpite
      slug.ts            # token de convite de liga
  app/
    layout.tsx           # shell global, fonte Plus Jakarta Sans, header LATAM
    globals.css          # tokens LATAM Pass (ver BRANDING)
    page.tsx             # home
    (auth)/
      login/page.tsx
      cadastro/page.tsx
    partidas/
      page.tsx           # lista de partidas
      [id]/page.tsx      # palpite de uma partida
    ranking/
      page.tsx           # ranking geral
    ligas/
      page.tsx           # minhas ligas + criar
      [id]/page.tsx      # ranking interno da liga
      entrar/[token]/page.tsx  # aceitar convite
    perfil/page.tsx
    regras/page.tsx      # regras e premios em milhas
    admin/
      page.tsx           # lista de partidas
      partidas/[id]/page.tsx   # inserir resultado
    actions/
      palpite.ts         # Server Actions de palpite
      liga.ts            # criar liga, entrar
      admin.ts           # encerrar partida, recalcular
      auth.ts            # cadastro
    api/
      auth/[...nextauth]/route.ts
  components/
    ui/                  # primitivos restilizados (botao, input, card)
    header.tsx           # header com listra/gradiente LATAM
    match-card.tsx
    score-input.tsx
    ranking-row.tsx
    league-card.tsx
    stripe-bar.tsx       # barra gradiente roxo-pink
  middleware.ts          # protege /admin e rotas autenticadas
  components.json        # shadcn (se usado)
  drizzle.config.ts
  next.config.ts
  tailwind.config.ts
  package.json
  vitest.config.ts
```

---

## Modelo de dados (Drizzle / Postgres)

### users
| Coluna | Tipo | Notas |
|---|---|---|
| id | uuid pk | |
| email | text unique not null | |
| password_hash | text not null | bcrypt |
| nickname | text unique not null | nome no ranking |
| favorite_team | text null | codigo da selecao |
| role | text not null default 'user' | 'user' ou 'admin' |
| is_premium | boolean not null default false | flag socio LATAM Pass (V2) |
| created_at | timestamptz default now | |

### teams
| Coluna | Tipo | Notas |
|---|---|---|
| code | text pk | ex 'BRA' |
| name | text not null | |
| flag_code | text not null | codigo do SVG em /public/flags |

### matches
| Coluna | Tipo | Notas |
|---|---|---|
| id | text pk | id do seed |
| phase | text not null | 'grupos','32avos','oitavas','quartas','semi','terceiro','final' |
| grp | text null | grupo quando aplicavel |
| home_code | text fk teams | |
| away_code | text fk teams | |
| stadium | text not null | |
| kickoff_at | timestamptz not null | horario oficial UTC. Define o prazo |
| home_score | int null | placar real, preenchido pelo admin |
| away_score | int null | |
| status | text not null default 'agendada' | 'agendada','ao_vivo','encerrada' |

### predictions
| Coluna | Tipo | Notas |
|---|---|---|
| id | uuid pk | |
| user_id | uuid fk users | |
| match_id | text fk matches | |
| home_guess | int not null | 0 a 20 |
| away_guess | int not null | 0 a 20 |
| points | int not null default 0 | gravado ao encerrar a partida |
| created_at | timestamptz default now | |
| updated_at | timestamptz default now | |
| unique(user_id, match_id) | | um palpite por partida |

### leagues
| Coluna | Tipo | Notas |
|---|---|---|
| id | uuid pk | |
| name | text not null | |
| owner_id | uuid fk users | |
| invite_token | text unique not null | nao adivinhavel |
| created_at | timestamptz default now | |

### league_members
| Coluna | Tipo | Notas |
|---|---|---|
| league_id | uuid fk leagues | |
| user_id | uuid fk users | |
| joined_at | timestamptz default now | |
| pk(league_id, user_id) | | |

### special_predictions (schema agora, UI em V2)
| Coluna | Tipo | Notas |
|---|---|---|
| user_id | uuid fk users | |
| type | text | 'campeao' ou 'artilheiro' |
| value | text | codigo da selecao ou nome do jogador |
| points | int default 0 | |
| pk(user_id, type) | | |

---

## Fluxos chave

### Registrar palpite
1. Usuario abre `/partidas/[id]`.
2. Server Component carrega a partida e o palpite existente.
3. Se `now >= kickoff_at`, formulario desabilitado. Prazo encerrado.
4. Submit chama Server Action `palpite.ts`.
5. Action valida com Zod, revalida prazo server-side, faz upsert em predictions.

### Encerrar partida e pontuar (admin)
1. Admin abre `/admin/partidas/[id]`, informa placar real.
2. Server Action `admin.ts` valida role admin.
3. Grava placar, status = encerrada.
4. Busca todos os palpites da partida.
5. Para cada um chama `scoring.ts` com palpite, resultado, fase e flag Brasil.
6. Grava points em cada palpite. Operacao idempotente.

### Ranking geral
1. `/ranking` roda query agregada: soma de points por usuario, ordenado desc.
2. Posicao com empate compartilhado.
3. Linha do usuario logado destacada no topo.

### Liga privada
1. `/ligas` cria liga via Server Action: gera invite_token, insere owner em members.
2. Convite `/ligas/entrar/[token]` valida token e insere membro.
3. `/ligas/[id]` agrega points apenas dos membros.

---

## Logica de pontuacao (contrato de lib/scoring.ts)

```ts
type MatchResult = { homeScore: number; awayScore: number };
type Guess = { homeGuess: number; awayGuess: number };
type Phase = 'grupos'|'32avos'|'oitavas'|'quartas'|'semi'|'terceiro'|'final';

// pontos-base sem multiplicador
export function basePoints(guess: Guess, result: MatchResult): number;

// multiplicador de fase
export function phaseMultiplier(phase: Phase): number;

// pontuacao final ja com Brasil e fase
export function finalPoints(args: {
  guess: Guess;
  result: MatchResult;
  phase: Phase;
  isBrazilMatch: boolean;
}): number;
```

Regras embutidas: pontuacao nao cumulativa (maior criterio vence), ordem
base x Brasil x fase, arredondamento para inteiro mais proximo. Todos os
exemplos de REQUISITOS secao 4 viram casos de teste em scoring.test.ts.

---

## Variaveis de ambiente (.env.example)

```
POSTGRES_URL=
POSTGRES_PRISMA_URL=
POSTGRES_URL_NON_POOLING=
AUTH_SECRET=
AUTH_URL=http://localhost:3000
```

---

## Seguranca aplicada

- Senha bcrypt. Sessao JWT NextAuth.
- middleware.ts protege /admin (role) e rotas que exigem login.
- Prazo de palpite e calculo de pontos sempre server-side.
- invite_token gerado com crypto, comprimento alto, unico.
- Ranking e totais sempre por query agregada no servidor.
