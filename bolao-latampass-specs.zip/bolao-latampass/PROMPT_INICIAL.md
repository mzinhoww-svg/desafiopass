# PROMPT_INICIAL.md

Cole o texto abaixo no Claude Code (no diretorio do projeto, com os 5 specs e este
arquivo ja presentes) para arrancar a execucao.

---

Voce vai construir o Bolao LATAM Pass Copa 2026. Antes de qualquer codigo, leia na
integra: CLAUDE.md, REQUISITOS.md, ESTRUTURA.md, BRANDING.md, ROADMAP.md.

Regras inviolaveis:
- Metodologia GSD2. Trabalhe uma Task por vez na ordem do ROADMAP. Comece na Task 0.1.
- Spec antes de codigo. Antes de cada Task, releia os must-haves dela e me confirme
  o plano em poucas linhas. So depois implemente.
- Ao terminar uma Task, verifique cada must-have explicitamente e faca um commit
  atomico no formato feat(scope): descricao. Rode lint, typecheck e test antes do
  commit quando ja existirem.
- Marca LATAM Pass conforme BRANDING.md. Plus Jakarta Sans, indigo Elevate #16064F, magenta
  #FE3173. Sem emojis na UI. Premio em milhas LATAM Pass.
- Dados dos jogos vem do seed estatico. Sem API externa de futebol no MVP.
- Logica de pontuacao isolada em lib/scoring.ts, funcao pura, testada antes da UI
  (Task 2.1 vem antes da 2.3).

Entregue a Task 0.1 (scaffold Next.js 15 + TypeScript + Tailwind v4, scripts de
package.json, repo Git inicial). Ao final, confirme o must-have: npm run dev sobe a
home com header LATAM. Depois pare e aguarde meu ok para seguir para a Task 0.2.

Contexto do dono para capas e rodapes quando aplicavel: Aurimar Reiners, PM de
Inovacoes, LATAM Pass Brasil, squad eLoyalty / New Business.
