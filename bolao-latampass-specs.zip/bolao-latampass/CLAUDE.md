# CLAUDE.md

Guia operacional para Claude Code neste repositorio. Leia antes de qualquer tarefa.

## O que e este projeto

Bolao de palpites da Copa do Mundo FIFA 2026, fase mata-mata, com identidade visual
LATAM Pass (design system ELEVATE 2025). Replica a mecanica do Bolao CazeTV/iFood:
usuario palpita placares, acumula pontos por acerto, sobe no ranking e disputa premios
em milhas LATAM Pass. Inclui ligas privadas para competir com amigos.

Projeto irmao do Desafio Pass. Mesma squad (eLoyalty / New Business), mesmo dono
(Aurimar Reiners), mesmo padrao de marca.

## Stack

- Next.js 15 (App Router, Server Components, Server Actions)
- TypeScript estrito
- Vercel Postgres (banco serverless)
- Drizzle ORM (schema e migracoes type-safe)
- NextAuth v5 (Auth.js) com Credentials provider
- Tailwind CSS v4 (tokens LATAM Pass injetados em globals.css)
- Deploy: Vercel. Repo: GitHub. CI: GitHub Actions + Vercel preview deploys.

## Metodologia obrigatoria: GSD2

Toda tarefa segue Milestone > Slice > Task. Spec antes de codigo. Cada task
verificavel por must-haves explicitos. Contexto fresco por task.

Antes de codar qualquer feature:
1. Confirme em qual Slice e Task voce esta (ver ROADMAP.md).
2. Releia os must-haves daquela task.
3. Implemente o minimo para passar nos must-haves. Sem escopo extra.
4. Verifique cada must-have antes de marcar como done.

Nunca pule a leitura de REQUISITOS.md e ESTRUTURA.md ao iniciar uma task.

## Regras de codigo

- TypeScript estrito. Zero `any` sem justificativa em comentario.
- Toda mutacao de dados via Server Action, nunca fetch client-side direto ao banco.
- Logica de pontuacao isolada em `lib/scoring.ts`. E funcao pura. Tem teste unitario.
  Nunca duplicar a regra de pontos em outro lugar.
- Dados dos jogos vem de seed estatico em `lib/data/copa2026.ts`. No MVP nao ha API
  externa de futebol. Resultados reais sao inseridos via painel admin.
- Validacao de input com Zod em toda Server Action e rota.
- Datas sempre em UTC no banco. Conversao para horario de Brasilia so na exibicao.
- Prazo de palpite: trava no horario oficial de inicio da partida. Server-side.
  Nunca confiar no client para validar prazo.

## Regras de marca (LATAM Pass ELEVATE 2025)

Detalhe completo em BRANDING.md. Resumo que nunca muda:

- Fonte unica: Plus Jakarta Sans. Nenhuma outra.
- Navy `#16064F` primario. Magenta `#FE3173` para CTA e destaque.
- Sem emojis na UI. Sem travessoes em texto de produto.
- Tom de copy: Aurimar PROF. Objetivo, direto, frases curtas, vocabulario claro.
- Listras asas e barra gradiente roxo-pink sao assinatura visual. Usar nos headers.
- Premios sempre em milhas LATAM Pass, nunca em reais ou cartao pre-pago.

## Regras de seguranca

- Senhas com hash bcrypt. Nunca em texto plano.
- Pontuacao calculada e gravada server-side apos resultado oficial. Client nunca
  envia pontos.
- Ranking lido de view ou query agregada. Nunca confiar em total enviado pelo client.
- Acesso a liga privada por token de convite unico e nao adivinhavel.
- Painel admin protegido por role. So usuario com `role = admin` insere resultados.

## Workflow de commit (structured-dev-workflow)

Fases por entrega: Planning, Build, Review, Done, Release.

- Branch por slice: `slice/01-palpites`, `slice/02-ligas`.
- Commit atomico por task. Mensagem no formato: `feat(scope): descricao curta`.
- Antes de push: `npm run lint && npm run typecheck && npm run test`.
- PR para `main` aciona preview deploy na Vercel. Merge so com checks verdes.
- Release: tag `vX.Y.Z` ao fechar um milestone.

## Comandos

```
npm run dev          # ambiente local
npm run build        # build de producao
npm run lint         # eslint
npm run typecheck    # tsc --noEmit
npm run test         # vitest (logica de scoring)
npm run db:generate  # gerar migracao Drizzle a partir do schema
npm run db:migrate   # aplicar migracoes
npm run db:seed      # popular jogos da Copa 2026 e dados de teste
npm run db:studio    # Drizzle Studio
```

## O que NAO fazer

- Nao adicionar feature fora do slice atual. Anotar em .planning/backlog.md.
- Nao integrar API externa de futebol no MVP. Seed estatico apenas.
- Nao implementar saque de premio. Premio e milha creditada, fora do escopo do app.
- Nao usar biblioteca de UI pronta com tema proprio (MUI, Chakra). Tailwind + tokens
  LATAM. shadcn/ui e permitido desde que restilizado com os tokens da marca.
- Nao quebrar a regra: pontuacao nao e cumulativa por partida. So o criterio mais
  alto vale. Ver REQUISITOS.md secao 4.
