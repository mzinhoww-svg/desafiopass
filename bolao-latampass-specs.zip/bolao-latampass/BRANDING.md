# BRANDING.md

Identidade visual do Bolao LATAM Pass, alinhada ao LATAM Pass Elevate Design System.

> NOTA DE PRIORIDADE (atualizada): a fonte unica de marca do app passou a ser o
> LLM_SYSTEM_GUIDE.md (Elevate Design System), com a traducao para o app em
> specs/DESIGN_SPEC.md. A paleta e a fonte abaixo foram atualizadas para o padrao
> Elevate (indigo #16064F, rosa #FE3173, teal #0AE7C6, lima, roxo; Plus Jakarta Sans).
> Onde este documento divergir do DESIGN_SPEC, o DESIGN_SPEC manda.

---

## Principios

1. Plus Jakarta Sans e a fonte do app (padrao Elevate). Fallback system-ui.
2. Indigo domina superficies de marca. Acento pontua (rosa em claro, teal em escuro).
   Regra de cor Elevate 60.30.10. Branco respira o conteudo.
3. Sem emojis na UI de produto. Sem travessoes em copy.
4. Listras asas e barra gradiente roxo-pink sao a assinatura. Aparecem nos headers
   e em quebras de secao.
5. Premio sempre em milhas LATAM Pass. Nunca reais, nunca cartao pre-pago.
6. Tom de copy: Aurimar PROF. Objetivo, direto, frase curta.

---

## Paleta

| Token | Hex | Uso |
|---|---|---|
| `--indigo` | `#16064F` | Fundo primario de marca, headers, capas |
| `--indigo-light` | `#2C1183` | Parceiro de gradiente, blocos de destaque |
| `--rose` | `#FE3173` | Acento em fundo claro: CTA, highlight, estado ativo |
| `--teal` | `#0AE7C6` | Acento em fundo escuro: dados, destaque |
| `--white` | `#FFFFFF` | Fundo de conteudo, texto sobre dark |
| `--off-white` | `#F3F3F3` | Linhas alternadas de tabela, cards sutis |
| `--lime` | `#C2F24A` | Positivo / destaque pontual |
| `--purple-accent` | `#9E4CFE` | Acento 2 / gradiente decorativo |
| `--black` | `#000000` | Texto sobre branco |
| `--caption` | `#555555` | Texto auxiliar, rodape, fonte de dado |
| `--green` | `#0F9D58` | Indicador positivo, acerto, progresso |
| `--yellow` | `#F4B400` | Atencao, estado pendente |

Gradiente assinatura: linear de `--purple` para `--pink` (135deg).

---

## Tipografia

Fonte: `"Plus Jakarta Sans", "Segoe UI", Tahoma, sans-serif` (fallback de sistema).

| Elemento | Tamanho mobile | Peso | Cor |
|---|---|---|---|
| Titulo de tela | 26px | bold | indigo ou branco |
| Subtitulo | 18px | regular | indigo ou branco |
| Titulo de card | 16px | bold | indigo |
| Corpo | 15px | regular | preto ou branco |
| Rotulo de input | 14px | medium | indigo |
| Caption / fonte | 12px | regular | caption |
| Numero grande (placar, pontos) | 32px | bold | indigo ou pink |

Caixa alta nos titulos de secao, espelhando o ELEVATE. Sem italico em UI, exceto
legenda de imagem.

---

## globals.css (tokens base)

```css
@import "tailwindcss";

:root {
  --indigo: #16064F;
  --purple: #2C1183;
  --pink: #FE3173;
  --pink-light: #FC4979;
  --white: #FFFFFF;
  --off-white: #F3F3F3;
  --black: #000000;
  --caption: #555555;
  --green: #0F9D58;
  --yellow: #F4B400;
  --grad: linear-gradient(135deg, var(--purple), var(--pink));
  --font-brand: "Plus Jakarta Sans", "Segoe UI", Tahoma, sans-serif;
}

@theme inline {
  --color-indigo: var(--indigo);
  --color-purple: var(--purple);
  --color-pink: var(--pink);
  --color-pink-light: var(--pink-light);
  --color-offwhite: var(--off-white);
  --color-caption: var(--caption);
  --color-brand-green: var(--green);
  --color-brand-yellow: var(--yellow);
  --font-sans: var(--font-brand);
}

body {
  font-family: var(--font-brand);
  color: var(--black);
  background: var(--white);
}

.stripe-bar {
  height: 4px;
  background: var(--grad);
  width: 100%;
}
```

Tailwind passa a expor `bg-indigo`, `text-pink`, `bg-offwhite`, etc.

---

## Componentes e padroes

### Header
Fundo indigo. Logo LATAM Pass (simbolo) no canto. Titulo da tela em branco, caixa
alta. Barra gradiente roxo-pink de 4px na borda inferior (`.stripe-bar`). As
listras asas aparecem como arte de canto em telas de destaque (home, ranking).

### Botao primario (CTA)
Fundo rosa `--pink`, texto branco, bold, cantos arredondados (radius 12px),
altura minima 48px para toque. Hover/active escurece levemente. Exemplo de copy:
"Palpitar agora", "Criar liga", "Entrar no grupo". Sem emoji.

### Botao secundario
Borda rosa, texto rosa, fundo branco ou transparente.

### Card de partida (match-card)
Fundo branco, borda sutil off-white, radius 16px. Bandeiras e codigos das selecoes,
campo "Voce palpitou" e, quando encerrada, "O placar foi" e os pontos em verde.
Multiplicador de fase exibido como selo (ex: "Quartas x1,6"). Jogo do Brasil ganha
selo rosa "x2 Brasil".

### Input de placar (score-input)
Dois campos numericos grandes, centralizados, com as bandeiras ao lado. Numero em
32px bold indigo. Stepper opcional. Bloqueado e em cinza quando o prazo passou.

### Linha de ranking (ranking-row)
Posicao a esquerda. Top 3 com badge colorido (1 indigo, 2 verde, 3 rosa),
espelhando o app de referencia. Apelido no centro, pontos a direita em bold.
Linha do usuario logado realcada em verde claro.

### Tabela de regras e premios
Cabecalho indigo, texto branco. Linhas alternadas branco e off-white. Coluna de
premio sempre em milhas LATAM Pass.

### Estados
- Positivo (acerto, progresso): verde `--green`.
- Pendente: amarelo `--yellow`.
- Vazio: texto caption centralizado. Ex: "Voce ainda nao entrou em nenhuma liga
  privada." Sem ilustracao de terceiro.

---

## Acessibilidade

- Contraste: branco sobre indigo e rosa sobre branco passam AA. Validar qualquer
  novo par.
- Foco visivel em todos os interativos (outline rosa de 2px).
- Inputs sempre com label associado.
- Area de toque minima 44px.

---

## Assets de marca

Reaproveitar do Desafio Pass e da skill latam-deck quando disponiveis:

- Logo LATAM Pass simbolo (header).
- Listras asas versao pink (canto de telas dark) e lavender (telas claras).
- Barra gradiente para borda inferior de header.

Caminho sugerido no projeto: `public/brand/`. No MVP, se faltar asset, a barra
gradiente CSS (`.stripe-bar`) substitui e a marca permanece reconhecivel.

---

## O que evitar

- Outra fonte que nao Plus Jakarta Sans.
- Emoji em botao, titulo ou microcopy.
- Travessao em texto de produto. Usar virgula ou frase curta.
- Verde ou amarelo como cor de marca. Sao so estados.
- Premio em reais ou cartao. Sempre milhas LATAM Pass.
