# Bolao LATAM Pass - Copa 2026 (Mata-Mata)

Bolao de palpites da Copa do Mundo FIFA 2026 com identidade visual LATAM Pass refinada
(ELEVATE 2025 mais inteligencia de design das skills impeccable, tripled-ui e
ui-ux-pro-max). Usuario palpita placares, acumula pontos, sobe no ranking e disputa
premios em milhas. Inclui ligas privadas. Projeto irmao do Desafio Pass.

## Pacote de engenharia (ler nesta ordem)

### Camada 1 - visao e regras
1. README.md (este arquivo)
2. CLAUDE.md - guia operacional do Claude Code
3. REQUISITOS.md - requisitos e regras de negocio
4. ROADMAP.md - plano GSD2 (Milestone, Slices, Tasks)

### Camada 2 - especificacoes normativas (contrato literal, anti-alucinacao)
5. specs/SCORING_SPEC.md - pontuacao: tipos, tabela de verdade, casos de teste
6. specs/RANKING_SPEC.md - ranking: desempate deterministico, edge cases, SQL
7. specs/DATA_SPEC.md - schema Drizzle literal, prazo, timezone, ligas
8. specs/DESIGN_SPEC.md - design refinado pelas 3 skills, resolve conflito de fonte,
   tokens de rank, motion, icones, checklist anti-slop
9. ESTRUTURA.md - arquitetura, pastas, fluxos
10. BRANDING.md - design system de marca base

### Camada 3 - execucao guiada e rastreavel
11. prompts/00_PROTOCOLO.md - protocolo anti-alucinacao e o CICLO de execucao
12. prompts/INDEX.md - biblioteca de prompts, ordem, etapa de design
13. prompts/00b_wireframe_refinado.md - preview visual antes de codar
14. prompts/NN_task_*.md - um prompt por task, com output esperado e registro no backlog
15. .planning/backlog.md - LOG VIVO. Memoria persistente. Toda task le e grava aqui.

### Visual
16. wireframes-refinado.html - 12 telas de alta fidelidade (referencia oficial)
17. wireframes.html - versao inicial (historico)

## O ciclo de execucao (rastreavel, anti-alucinacao)

Toda task roda cinco passos, definidos no 00_PROTOCOLO.md:

1. LER E PLANEJAR: le o backlog inteiro, marca a task EM ANDAMENTO, escreve o plano.
2. EXECUTAR: implementa o minimo, marcando sub-itens no backlog.
3. VALIDAR: confere cada must-have contra o OUTPUT ESPERADO, roda lint/typecheck/test.
4. GRAVAR: commit atomico, move a task para CONCLUIDA, registra decisoes e log.
5. ENTREGAR E PARAR: confirma o output, aguarda ok para a proxima.

O backlog e a memoria viva. Como cada task roda em contexto fresco, o backlog garante
que nada se perde entre sessoes e que decisoes ja tomadas nao sao reabertas.

## Por que tres camadas de spec

Camada 1 diz O QUE. Camada 2 diz EXATAMENTE COMO, com tipos literais, tabelas de verdade
e casos de teste, para nao haver preenchimento por suposicao. Camada 3 governa o
comportamento do agente e mantem o estado rastreavel. As zonas criticas (pontuacao,
ranking, design) tem contrato ao pe da letra mais checklist de verificacao.

## Stack

Next.js 15 App Router, TypeScript estrito, Vercel Postgres, Drizzle, NextAuth v5,
Tailwind v4, Framer Motion, Lucide. Deploy Vercel. Repo GitHub. CI GitHub Actions.

## Como comecar no Claude Code

1. Abra a pasta no Claude Code.
2. Aprove a direcao visual: abra wireframes-refinado.html (ou rode a etapa 0b).
3. Cole prompts/00_PROTOCOLO.md + prompts/01_task_0_1_scaffold.md.
4. Siga a ordem de prompts/INDEX.md, uma task por vez. O backlog registra tudo.

## Metodologia

GSD2: Milestone > Slice > Task, spec antes de codigo, must-have verificavel, contexto
fresco por task, log vivo no backlog. Marca: Plus Jakarta Sans com estetica atletica, navy
#16064F, magenta #FE3173, podio ouro/prata/bronze, sem emoji estrutural, premio em
milhas LATAM Pass.
