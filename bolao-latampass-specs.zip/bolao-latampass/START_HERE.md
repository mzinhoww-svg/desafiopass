# START HERE - Bolao LATAM Pass Copa 2026

Entrega consolidada. Pacote de engenharia completo para construir o bolao da Copa do
Mundo FIFA 2026, fase mata-mata, com identidade LATAM Pass, usando Claude Code, Next.js
15, Vercel Postgres e GitHub.

Este arquivo e o mapa. Leia-o primeiro e siga as setas.

---

## O que e esta entrega

Tudo que o Claude Code precisa para construir o app sem alucinar: regras de negocio,
contratos tecnicos literais, design refinado, biblioteca de prompts por task, log de
execucao rastreavel, wireframes e o modulo de pontuacao ja codado e testado.

Total: 42 arquivos. ZIP unico anexo: bolao-latampass-specs.zip.

---

## Ordem de leitura para humano (10 minutos)

1. Este arquivo (START_HERE.md).
2. README.md - visao geral e como comecar.
3. wireframes-refinado.html - abra no navegador, veja as 12 telas. APROVE a direcao.
4. ROADMAP.md - o plano em Slices e Tasks.

Depois disso voce ja sabe o que sera construido e em que ordem.

---

## Ordem de execucao para o Claude Code

Abra o projeto no Claude Code e siga prompts/INDEX.md. Resumo:

```
Etapa de design (opcional, ja temos o HTML pronto):
  00b_wireframe_refinado.md     -> preview visual para aprovar

Desenvolvimento (uma task por vez, na ordem):
  01 scaffold -> 02 design -> 03 banco -> 04 seed -> 05 deploy
  06 auth -> 07 cadastro -> 08 perfil
  09 SCORING (critico, ja temos o codigo em reference-code/)
  10 lista -> 11 palpite -> 12 admin pontua -> 13 resultado
  14 RANKING (sensivel)
  15 criar liga -> 16 entrar liga -> 17 ranking liga
  18 regras -> 19 home -> 20 QA -> 21 release
```

Em cada task: cole prompts/00_PROTOCOLO.md + o arquivo da task. O agente le o backlog,
planeja, executa marcando, valida contra o output esperado, grava no backlog, commita,
para.

---

## Mapa completo de arquivos

### Raiz - visao e regras
- START_HERE.md ........... este mapa
- README.md ............... visao geral e setup
- CLAUDE.md ............... guia operacional do Claude Code
- REQUISITOS.md ........... requisitos e regras de negocio
- ROADMAP.md .............. plano GSD2 (Milestone, Slices, Tasks)
- ESTRUTURA.md ............ arquitetura, pastas, fluxos
- BRANDING.md ............. design system de marca base
- PROMPT_INICIAL.md ....... prompt curto de arranque (alternativo ao INDEX)
- .env.example ............ variaveis de ambiente

### specs/ - contratos literais (anti-alucinacao)
- SCORING_SPEC.md ......... pontuacao: tipos, tabela de verdade, casos de teste
- RANKING_SPEC.md ......... ranking: desempate deterministico, edge cases, SQL
- DATA_SPEC.md ............ schema Drizzle, prazo, timezone, ligas
- DESIGN_SPEC.md .......... design refinado pelas 3 skills, resolve conflito de fonte

### prompts/ - execucao guiada e rastreavel
- 00_PROTOCOLO.md ......... protocolo anti-alucinacao e o CICLO de 5 passos
- INDEX.md ................ biblioteca, ordem, sequencia de design
- 00b_wireframe_refinado.md preview antes de codar
- 01..21 task_*.md ........ um prompt por task (output esperado + registro no backlog)

### .planning/
- backlog.md ............. LOG VIVO. Memoria persistente. Toda task le e grava aqui.

### reference-code/ - codigo pronto e validado
- README.md .............. como usar
- lib/scoring.ts ......... logica de pontuacao implementada (Task 2.1)
- lib/scoring.test.ts .... suite com os 27 casos da spec. Verificada: 49 asseroes verdes.

### Visual
- wireframes-refinado.html  12 telas de alta fidelidade (referencia oficial)
- wireframes.html ......... versao inicial (historico)

---

## Os tres pilares anti-alucinacao

1. Contratos literais (specs/): tipos exatos, tabelas de verdade, SQL, edge cases
   enumerados. O agente implementa, nao inventa.
2. Ciclo rastreavel (00_PROTOCOLO.md + backlog.md): ler, planejar, marcar, validar,
   gravar, entregar. O backlog e a memoria entre sessoes de contexto fresco.
3. Codigo critico pronto (reference-code/): o modulo de pontuacao, onde erro custa mais,
   ja vem implementado e testado.

---

## Decisoes travadas (nao reabrir no codigo)

- Stack: Next.js 15 App Router, TypeScript estrito, Vercel Postgres, Drizzle, NextAuth
  v5, Tailwind v4, Framer Motion, Lucide. Deploy Vercel, repo GitHub, CI GitHub Actions.
- MVP: palpites, pontuacao, ranking geral, ligas privadas. Jogos via seed estatico.
- Pontuacao: regra unica em lib/scoring.ts, pura, testada. Nao cumulativa.
- Ranking: competition ranking, desempate por pontos, placares exatos, created_at, id.
  Pontos zero exibe travessao.
- Prazo: trava no kickoff (now === kickoff recusa). UTC no banco, Brasilia na exibicao.
- Design: Plus Jakarta Sans com estetica atletica, estrategia committed navy, podio
  ouro/prata/bronze, Lucide, Framer Motion, banimentos do impeccable.
- Premio sempre em milhas LATAM Pass.

---

## Pendencias para o time (fora do escopo do codigo)

- Valores de premio em milhas por faixa de posicao.
- Confirmacao dos confrontos reais do mata-mata para o seed (placeholders onde indefinido).
- Opcional: aprovar formalmente uma fonte display condensada dedicada ao bolao.

---

## Como comecar agora

1. Descompacte bolao-latampass-specs.zip.
2. Abra wireframes-refinado.html e aprove a direcao visual.
3. Abra a pasta no Claude Code.
4. Cole prompts/00_PROTOCOLO.md + prompts/01_task_0_1_scaffold.md.
5. Siga prompts/INDEX.md, uma task por vez. Quando chegar na Task 2.1, use o codigo
   pronto de reference-code/lib/.
