# ROADMAP.md

Plano de execucao GSD2. Milestone unico para o MVP, quebrado em Slices, cada Slice
em Tasks com must-haves verificaveis. Contexto fresco por task. Spec antes de codigo.

Marcacao de estado: [ ] pendente, [~] em andamento, [x] done.

---

## Milestone 1: Bolao MVP jogavel

Definicao de done do milestone:
- Usuario cadastra, loga, palpita placares do mata-mata, ve seus pontos calculados
  corretamente, sobe no ranking geral, cria e entra em liga privada por link.
- Admin insere resultado e dispara a pontuacao.
- Visual LATAM Pass aplicado. Deploy na Vercel a partir do GitHub.

---

### Slice 0: Fundacao

Objetivo: projeto roda, banco conecta, marca aplicada, deploy de pe.

Task 0.1 Scaffold
- [ ] Next.js 15 + TypeScript + Tailwind v4 criado.
- [ ] Scripts de package.json: dev, build, lint, typecheck, test, db:*.
- [ ] Repo GitHub criado, primeiro commit, push.
Must-have: `npm run dev` sobe a home em branco com header LATAM.

Task 0.2 Tokens de marca
- [ ] globals.css com tokens de BRANDING.md.
- [ ] tailwind expoe cores navy, pink, offwhite, etc.
- [ ] Fonte Plus Jakarta Sans aplicada no body. Componente stripe-bar.
- [ ] Header com navy, titulo caixa alta e barra gradiente.
Must-have: home mostra header LATAM com gradiente e fonte correta.

Task 0.3 Banco e ORM
- [ ] Vercel Postgres provisionado. .env.example preenchido.
- [ ] Drizzle configurado. drizzle/schema.ts com todas as tabelas de ESTRUTURA.md.
- [ ] db:generate e db:migrate funcionam.
Must-have: migracao aplica e cria as tabelas no Postgres.

Task 0.4 Seed Copa 2026
- [ ] lib/data/copa2026.ts com selecoes e jogos do mata-mata (chaveamento fixo).
- [ ] db:seed popula teams e matches.
Must-have: tabela matches populada com os jogos do mata-mata e horarios UTC.

Task 0.5 Deploy
- [ ] Projeto conectado a Vercel. Preview deploy por PR.
- [ ] GitHub Actions: lint + typecheck + test no PR.
Must-have: push em branch gera preview deploy verde na Vercel.

---

### Slice 1: Auth e perfil

Objetivo: identidade do usuario.

Task 1.1 NextAuth Credentials
- [ ] lib/auth.ts com NextAuth v5, Credentials, sessao JWT.
- [ ] api/auth/[...nextauth]/route.ts.
- [ ] middleware.ts protege rotas autenticadas e /admin.
Must-have: login e logout funcionam com usuario semeado.

Task 1.2 Cadastro
- [ ] /cadastro: email, senha, apelido, confirmacao 16+, aceite de termos.
- [ ] Server Action cria usuario, hash bcrypt, valida apelido unico (Zod).
Must-have: cadastro cria usuario e bloqueia apelido duplicado com mensagem clara.

Task 1.3 Perfil
- [ ] /perfil: apelido, time do coracao, total de pontos.
- [ ] Editar apelido e time do coracao via Server Action.
Must-have: perfil exibe dados e salva edicao.

---

### Slice 2: Palpites e pontuacao

Objetivo: o coracao do bolao.

Task 2.1 Logica de pontuacao (primeiro, isolada)
- [ ] lib/scoring.ts: basePoints, phaseMultiplier, finalPoints (contrato de ESTRUTURA).
- [ ] lib/scoring.test.ts cobre todos os exemplos de REQUISITOS secao 4.
Must-have: `npm run test` passa em todos os casos, incluindo Brasil x2 e multiplicador
de fase. Final jogo do Brasil placar exato = 200.

Task 2.2 Lista de partidas
- [ ] /partidas: Server Component lista por data e fase.
- [ ] match-card mostra selecoes, selo de fase, selo Brasil, estado do palpite.
Must-have: lista exibe os jogos do seed agrupados por fase com selos corretos.

Task 2.3 Registrar palpite
- [ ] /partidas/[id] com score-input. Carrega palpite existente.
- [ ] Server Action faz upsert. Valida prazo server-side (kickoff_at).
- [ ] Apos prazo, formulario travado.
Must-have: palpite salva, edita antes do prazo e trava depois do kickoff.

Task 2.4 Encerrar e pontuar (admin)
- [ ] /admin lista partidas. /admin/partidas/[id] insere placar.
- [ ] Server Action valida role admin, grava placar, status encerrada.
- [ ] Percorre palpites, chama scoring, grava points. Idempotente.
Must-have: ao inserir resultado, os pontos de todos os palpites sao gravados
corretamente e reencerrar nao duplica.

Task 2.5 Resultado na UI
- [ ] match-card encerrado mostra "O placar foi" e pontos em verde.
Must-have: partida encerrada exibe placar real e pontos do usuario.

---

### Slice 3: Ranking

Objetivo: competicao publica.

Task 3.1 Ranking geral
- [ ] /ranking: query agregada soma points por usuario, ordena desc.
- [ ] Empate compartilha posicao. Top 3 com badge.
- [ ] Linha do usuario logado destacada no topo, mesmo fora do top visivel.
Must-have: ranking ordena por pontos, trata empate e destaca o usuario logado.

---

### Slice 4: Ligas privadas

Objetivo: competir com amigos.

Task 4.1 Criar liga
- [ ] /ligas: criar liga (nome). Gera invite_token unico via crypto.
- [ ] Dono entra como membro. Limite de 1 liga para usuario basico.
Must-have: criar liga gera link de convite e inscreve o dono.

Task 4.2 Entrar na liga
- [ ] /ligas/entrar/[token] valida token e inscreve membro.
Must-have: abrir o link de convite inscreve o usuario na liga.

Task 4.3 Ranking da liga
- [ ] /ligas/[id]: ranking interno so dos membros, mesma pontuacao acumulada.
- [ ] /ligas lista minhas ligas (criadas e entradas).
Must-have: liga mostra ranking apenas dos membros, ordenado por pontos.

---

### Slice 5: Regras, premios e acabamento

Objetivo: fechar o MVP com a cara do produto.

Task 5.1 Regras e premios
- [ ] /regras: regras espelhando REQUISITOS, tabela de premios em milhas LATAM Pass.
Must-have: tela de regras completa, premio em milhas, sem mencao a reais.

Task 5.2 Home
- [ ] / home: destaque do bolao, proximos jogos do mata-mata, CTA palpitar.
Must-have: home com identidade LATAM e atalho para palpitar.

Task 5.3 QA e responsivo
- [ ] Revisar mobile first em todas as telas. Contraste, foco, labels.
- [ ] lint, typecheck, test verdes. Sem any injustificado.
Must-have: navegacao completa no mobile sem quebra. Checks verdes.

Task 5.4 Release
- [ ] Merge na main. Deploy de producao na Vercel. Tag v1.0.0.
Must-have: producao no ar, fluxo ponta a ponta funciona.

---

## Ordem de ataque

Slice 0 inteiro antes de tudo. Dentro do Slice 2, a Task 2.1 (scoring testado) vem
antes da UI de palpite. Isso garante a regra correta antes de qualquer tela
depender dela. Ligas (Slice 4) so depois do ranking (Slice 3), pois reaproveitam a
mesma agregacao de pontos.

## Fora do MVP (registrar em .planning/backlog.md, nao implementar agora)

Palpites especiais (campeao, artilheiro). Ranking exclusivo socio LATAM Pass.
Rankings independentes por recorte (Copa completa, mata-mata, quartas). Estatistica
da comunidade. API externa de futebol. Avanco dinamico de chaveamento. Saque ou
credito automatico de milhas. Sair e gerenciar membros de liga. Login social e
recuperacao de senha.
