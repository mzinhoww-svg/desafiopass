# REQUISITOS.md

Requisitos funcionais e regras de negocio do Bolao LATAM Pass Copa 2026.
Fonte da verdade para comportamento. Extraido da mecanica do Bolao CazeTV/iFood,
adaptado para marca LATAM Pass e premiacao em milhas.

Convencao: must-have marcado com [M] e obrigatorio no MVP. [V2] e versao futura.

---

## 1. Conta e acesso

- [M] Cadastro com email, senha e apelido unico. Apelido e o nome exibido no ranking.
- [M] Login e logout via NextAuth (Credentials).
- [M] Apelido unico no banco. Bloquear duplicado com mensagem clara.
- [M] Idade minima 16 anos declarada no cadastro (checkbox de confirmacao).
- [M] Aceite dos termos no cadastro.
- [M] Papel de usuario: `user` ou `admin`. Default `user`.
- [V2] Login social. Recuperacao de senha por email.
- [V2] Vinculo com conta LATAM Pass real e numero de socio.

---

## 2. Estrutura do torneio (seed estatico Copa 2026)

- [M] Os jogos vem de `lib/data/copa2026.ts`. Sem API externa no MVP.
- [M] Cada partida tem: id, fase, grupo (quando aplicavel), selecao mandante,
  selecao visitante, estadio, data e horario oficial de inicio (UTC), placar
  mandante, placar visitante, status.
- [M] Fases suportadas: fase de grupos, 32-avos, oitavas, quartas, semifinal,
  disputa de 3 e 4 lugar, final. O foco do produto e o mata-mata, mas o modelo
  cobre a Copa toda para reaproveitar as regras de multiplicador.
- [M] Status da partida: `agendada`, `ao_vivo`, `encerrada`.
- [M] Cada selecao tem codigo (ex: BRA), nome e bandeira (emoji ou caminho de asset).
- [M] No mata-mata, o chaveamento e fixo no seed. V2 trata avanco dinamico.

---

## 3. Palpites

- [M] Para cada partida o usuario escolhe um placar (mandante x visitante).
- [M] Um palpite por partida por usuario.
- [M] Palpite pode ser editado a qualquer momento antes do prazo. Vale o ultimo.
- [M] Prazo: horario oficial de inicio da partida. Validado server-side. Apos o
  prazo o palpite trava e nao pode ser alterado nem criado.
- [M] Palpite so com numeros inteiros nao negativos. Limite razoavel (0 a 20).
- [M] Tela mostra "Voce palpitou" e, apos encerrada, "O placar foi" e os pontos
  ganhos naquela partida.
- [V2] Palpites especiais: campeao da Copa e artilheiro, +150 pontos cada,
  travados no inicio do primeiro jogo. Fora do MVP mas previsto no schema.

---

## 4. Pontuacao (logica em lib/scoring.ts, funcao pura, testada)

Pontos-base por resultado do palpite. A pontuacao NAO e cumulativa: vale apenas
o criterio mais alto em que o palpite se enquadra.

| Resultado do palpite | Pontos-base |
|---|---|
| Placar exato | 50 |
| Selecao vencedora correta + gols de uma das selecoes (sem placar exato) | 35 |
| Selecao vencedora correta (sem acertar gols) | 20 |
| Empate correto (sem acertar o placar exato do empate) | 20 |
| Palpite errado ou sem palpite | 0 |

- [M] A funcao recebe palpite e resultado real e devolve os pontos-base.
- [M] Disputa de penalti nao conta. Resultado considerado e o placar ao fim do
  tempo regulamentar ou da prorrogacao.
- [M] Sem palpite registrado no prazo = 0 pontos naquela partida.

### Multiplicadores

Aplicados sobre os pontos-base, nesta ordem: base x Mult.Brasil x Mult.Fase.

- [M] Multiplicador Brasil: em qualquer partida da selecao brasileira, pontos-base
  multiplicados por 2.
- [M] Multiplicador de fase:

| Fase | Multiplicador |
|---|---|
| Fase de grupos | x1 |
| 32-avos | x1,2 |
| Oitavas | x1,4 |
| Quartas | x1,6 |
| Semifinal e disputa 3/4 lugar | x1,8 |
| Final | x2 |

- [M] Formula final: `pontos = base * multBrasil * multFase`.
- [M] Exemplos que o teste unitario deve cobrir:
  - Grupos, sem Brasil, acerta vencedor sem gols: 20 x 1 x 1 = 20.
  - Grupos, jogo do Brasil, vencedor + gols: 35 x 2 x 1 = 70.
  - Oitavas, sem Brasil, vencedor + gols: 35 x 1,4 = 49.
  - Quartas, sem Brasil, placar exato: 50 x 1,6 = 80.
  - Final, sem Brasil, placar exato: 50 x 2 = 100.
  - Oitavas, jogo do Brasil, empate sem placar exato: 20 x 2 x 1,4 = 56.
  - Semifinal, jogo do Brasil, vencedor + gols: 35 x 2 x 1,8 = 126.
  - Final, jogo do Brasil, placar exato: 50 x 2 x 2 = 200.
- [M] Arredondamento: resultado final arredondado para inteiro. Definir regra no
  teste (arredondar para o inteiro mais proximo, .5 para cima).

---

## 5. Calculo e gravacao de pontos

- [M] Pontos sao calculados server-side quando o admin marca a partida como
  encerrada e informa o placar real.
- [M] Ao encerrar a partida, o sistema percorre todos os palpites daquela partida,
  calcula os pontos e grava em cada palpite.
- [M] Recalculo idempotente: encerrar de novo a mesma partida recalcula sem somar
  em dobro.
- [M] Total do usuario e a soma dos pontos de todos os seus palpites em partidas
  encerradas. Lido por query agregada, nunca enviado pelo client.

---

## 6. Ranking

- [M] Ranking geral: todos os participantes ordenados por pontos, desc.
- [M] Empate de pontos compartilha a posicao (ex: tres usuarios em 5 lugar).
- [M] Mostrar posicao do usuario logado, apelido e total, no topo, mesmo que ele
  esteja fora do top visivel.
- [M] Paginacao ou scroll do ranking. Top 100 carregado, resto sob demanda.
- [V2] Ranking exclusivo de assinante (equivalente ao "Clube iFood"). No nosso
  caso, ranking exclusivo LATAM Pass Black ou socio. Schema preve flag, UI fica V2.
- [V2] Rankings independentes por recorte (Copa completa, mata-mata, quartas).
  No MVP existe um ranking geral unico acumulado.

---

## 7. Ligas privadas

- [M] Usuario cria liga privada com nome. Vira dono da liga.
- [M] Liga gera token de convite unico. Link de convite: `/ligas/entrar/{token}`.
- [M] Outro usuario entra na liga pelo link.
- [M] Tela da liga mostra ranking interno: so os membros, ordenados por pontos.
- [M] Mesma pontuacao acumulada do ranking geral e usada na liga.
- [M] Usuario ve a lista de ligas que criou ou entrou.
- [M] Limite no MVP: usuario basico cria ou entra em ate 1 liga. Schema e regra
  preparados para elevar o limite a 100 para socio LATAM Pass (V2).
- [M] Sem limite de participantes por liga.
- [V2] Sair da liga. Remover membro. Renomear. Transferir dono.

---

## 8. Painel admin

- [M] Rota protegida por role admin.
- [M] Listar partidas. Marcar partida como encerrada informando o placar real.
- [M] Ao salvar o placar, dispara o calculo de pontos da secao 5.
- [M] Editar placar de partida ja encerrada e recalcular (idempotente).
- [V2] CRUD completo de partidas e selecoes pela UI. No MVP os jogos vem do seed.

---

## 9. Premiacao (informativa no MVP)

- [M] Tela de regras e premios em milhas LATAM Pass. Tabela de faixas por posicao.
- [M] Premio expresso em milhas, nunca em reais. Texto deixa claro que credito de
  milhas e processo fora do app (operacional LATAM Pass).
- [M] Conteudo de regras espelha a logica de pontuacao e prazos deste documento.
- Estrutura de premiacao (placeholder, numeros a confirmar com o time):

| Posicao | Premio (milhas LATAM Pass) |
|---|---|
| 1 | a definir |
| 2 | a definir |
| 3 | a definir |
| 4 ao 10 | a definir |
| 11 ao 100 | a definir |

- [V2] Calculo e credito automatico. Integracao com base de socios.

---

## 10. Estatistica da comunidade

- [V2] Percentual da comunidade em cada resultado de uma partida (ex: "73% palpitam
  vitoria do Brasil"). Previsto, fora do MVP.

---

## 11. Telas do MVP

- [M] Home: destaque do bolao, proximos jogos do mata-mata, atalho para palpitar.
- [M] Partidas: lista por data e fase, com estado do palpite e resultado.
- [M] Tela de palpite por partida.
- [M] Ligas: aba liga publica (ranking geral) e liga privada (criar, entrar, ver).
- [M] Perfil: apelido, time do coracao, total de pontos.
- [M] Ranking: geral, com posicao do usuario.
- [M] Regras e premios.
- [M] Admin: lista de partidas e insercao de resultado.

---

## 12. Nao funcionais

- [M] Mobile first. O bolao e consumido no celular. Layout de coluna unica,
  area de toque generosa.
- [M] Acessibilidade basica: contraste adequado, foco visivel, labels em inputs.
- [M] Sem segredo no client. Tudo sensivel em Server Action ou rota server.
- [M] Performance: telas principais com Server Components e cache adequado.
