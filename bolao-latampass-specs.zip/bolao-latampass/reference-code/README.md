# reference-code

Codigo de referencia ja implementado e validado. Pronto para colar no projeto quando a
task correspondente comecar. Nao e o app inteiro; sao os modulos criticos entregues
prontos para acelerar e travar a corretude.

## lib/scoring.ts e lib/scoring.test.ts

Implementacao completa da logica de pontuacao (Task 2.1), seguindo
specs/SCORING_SPEC.md ao pe da letra. Funcao pura, sem I/O.

Validacao: os 27 casos da spec (B1 a B14 e F1 a F13) mais ScoreBreakdown, arredondamento
half up e palpite null foram verificados. 49 asseroes, todas verdes.

Como usar:
1. Na Task 0.1, com o projeto Next criado, copie scoring.ts para lib/scoring.ts.
2. Copie scoring.test.ts para lib/scoring.test.ts.
3. Garanta vitest no projeto e rode `npm run test`. Deve passar 100%.
4. Nenhum outro arquivo deve recalcular pontos. Todos chamam finalPoints.

Casos cobertos (resumo):
- Placar exato, vencedor + gols, vencedor, empate, errado, sem palpite.
- B11: visitante vence e gols do mandante batem (o erro classico).
- Empate nunca retorna vencedor_e_gols.
- Multiplicador Brasil x2 e multiplicadores de fase.
- F8: final, Brasil, placar exato = 200.
- Arredondamento half up.
